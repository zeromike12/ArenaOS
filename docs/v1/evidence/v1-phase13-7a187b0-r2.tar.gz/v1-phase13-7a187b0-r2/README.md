# Phase 13 registry regression evidence — candidate 7a187b0, run r2

## Result

**Focused Phase 13 regression: PASS.** This is evidence for this test only and does not close Requirement 4b or constitute V1 acceptance.

The run is bound by `run.json` to branch `arena/af044828-arenaos`, candidate commit `7a187b06099013d280c004116971ff1c926bfb7b`, and the canonical EFI/ESP hashes. The test's main Phase 13 guest boot completed in 415.699 seconds with its **600-second timeout unchanged**. The AFS2 favorites reload completed in 9.130 seconds with its 90-second timeout. Seed and AFS2 initialization retained the harness's 120-second defaults.

The test verified APB1 installation, registry launch, keyboard/search/pointer response of the signed native ELF, five installed instances, 26 mixed AppInstances, 32 windows, five live helpers, two parked user threads, half-close/reuse/full teardown, a headless app, persisted AFS2 favorite reload on the next boot, exact identity-resource teardown to baseline, and clean shutdown. `run.json` and serial logs are the source of record for exact assertions and hashes.

## Contents

- `run.json`, `commands.txt`: run identity, command, candidate, artifacts, timeouts, status and measured durations.
- `serial/`, `attempts/boots/`: complete raw serial output, QEMU stderr/network logs, virtual-console transcripts, and per-boot receipts for seed, AFS2, main workload, and favorites reload.
- `*-qmp-trace.jsonl`, `*-wait-trace.jsonl`: append-only QMP command/response and wait/progress traces.
- `artifacts/arena-boot.efi`, `artifacts/arena-esp.img`: exact boot artifacts used by the run.
- `SHA256SUMS`: hashes of every other file in this evidence directory.

The Phase 13 harness itself ran headless and did not emit screenshots. Genuine QEMU milestone screenshots from the separate GCC/Clang guest proof are retained in the V1 gate evidence; they supplement, and do not substitute for, those runs' acknowledgments, syscall results, and resource accounting.

Requirement 4b remains **OPEN** absent M's explicit disposition. Historical failures remain historical; this focused pass does not erase them.
