# Supplemental raw stability evidence — candidate 7a187b0, gate r4

## Result and scope

`tools/stability_loop.sh 100` completed **100/100 fully green boots** in 1,069 seconds, zero failures. It ran against the canonical desktop EFI SHA-256 `b2fc4a295bfa5ef33c141f2fcfd099af5a761c25250592371996a02d6eba377a`; the final ESP SHA-256 was `a2f9821206c8efb22f13a6b3bcb92d5c6bd30b4bd60cef9bf3673b6280950551`. The independent `stability-receipt.txt` binds the 100/100 result to that EFI, and `gate/stability-stage-receipt.json` records the candidate commit, code fingerprint and EFI/ESP identities.

This archive is a **supplement** to the strict, freshly verified `v1-acceptance-7a187b0-r4.tar.gz`; it does not replace or modify that package. Requirement 4b remains OPEN, so V1 qualification remains BLOCKED / NOT ACCEPTED.

## Preserved raw material

- `stability.log` and `stability-expected.txt`: complete loop summary, ten-boot progress marks and boot-1-derived suite verdict set.
- `boots/boot-NNN-pixels.txt`: all 100 per-boot QMP pixel/input/drag/relaunch/lifecycle receipts.
- `boots/boot-NNN-udp-dns.log`: all 100 per-boot host DNS-fixture logs; each was checked to contain exactly three guest queries.
- `screenshots/boot-001.ppm` and `boot-100.ppm`: original QEMU/QMP PPM screendumps of the first and last boot, retained by the stability harness. The lossless PNGs alongside them are viewable re-encodings; both original PPMs have the same SHA-256 and raster hash.
- `serial-boot-100.log`, `tcp-boot-100.log`, `udp-dns-boot-100.log`, and `vcon-*`: final-boot raw outputs and fixture evidence.
- `gate/`: the stability stage receipt and the final aggregate, which records the independent 4b OPEN blocker.
- `SHA256SUMS`: hashes of every other file in this supplement.

The upstream default stability loop intentionally reuses one serial log and retains screenshot PPMs for boot 1 and boot 100. Accordingly, the per-boot raw serial transcript is not present for boots 1–99; no transcript has been fabricated. Each of those successful attempts is represented by the loop's live full-predicate check, its preserved pixel receipt, its preserved DNS fixture log, and the 10-boot progress count.
