# v1-acceptance-7a187b0-r4 — V1 evidence package

Produced 2026-11-10T18:37:38Z from commit
`7a187b06099013d280c004116971ff1c926bfb7b` on branch `arena/af044828-arenaos`
(working tree dirty: `True`).

## What is here

This package records evidence and classifications; it does not declare V1
accepted or qualified. Read the current aggregate and status note before using
any result.

| Kind | Count | Notes |
|---|---|---|
| Serial logs | 77 | The guest's own output under QEMU TCG |
| Screenshots | 46 | The exact frames each checkpoint assertion was made on (PNG, losslessly re-encoded from the QEMU screendump raster) |
| Manifests and receipts | 85 | JSON verdicts, identities, build receipts |

## How to check it

Extract the archive anywhere and verify every recorded digest from a fresh
directory (nothing is compared against the original workspace):

```sh
tar xzf v1-acceptance-7a187b0-r4.tar.gz
cd v1-acceptance-7a187b0-r4 && python3 - <<'PY'
import hashlib, json, pathlib
root = pathlib.Path("v1-acceptance-7a187b0-r4")
m = json.loads((root / "MANIFEST.json").read_text())
bad = []
for rel, want in m["files"].items():
    p = root / rel
    if not p.is_file():
        bad.append((rel, "missing"))
        continue
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    if got != want["sha256"] or p.stat().st_size != want["size"]:
        bad.append((rel, got + " != " + want["sha256"]))
print("files:", len(m["files"]), "mismatches:", len(bad))
for b in bad:
    print(" ", b)
raise SystemExit(1 if bad else 0)
PY
```

`tools/v1_evidence.py verify <archive>` performs exactly this check, plus a
scan for files that exist in the archive but not in the manifest.

`package` refuses to run unless every guest run in this directory publishes
all nine checkpoint images, each PNG still decoding to the raster digest the
harness recorded when that checkpoint passed. Real-grant integration PNGs are
independently decoded and checked against their recorded QEMU raster digest.
The 301-page rendered frame must carry a true visual assertion, all three
(top/middle/bottom) band assertions, valid on-screen geometry bound to the
identified surface and serial placement receipt, and actual checker pixels in
each band. Human-readable assertion prose is not part of the contract.

PPM working copies are not shipped (84 of them): a PPM is a fixed
header plus the identical raster, so it is reproducible from the published
PNG, and each tested PPM's own SHA-256 is recorded in its run's
`evidence.json`.

## How the verdicts were produced

- `guest-gcc/`, `guest-clang/`: `tools/v1_guest_proof.py` — eight
  checkpoints; `evidence.json` is the run's own verdict, `harness-output.log`
  is the transcript, `v1-guest-serial.log` is the guest serial, `shots/` are
  the frames, `qemu-stderr.log` is the emulator's stderr.
- `phase15/`: `tools/test_m15_guest.py` — both final-ESP CPU profiles, with
  serial logs and QEMU stderr tied to the exact EFI/ESP identities in the gate
  receipts.
- `layout-integration-gcc/`, `layout-integration-clang/`:
  `tools/v1_layout_integration.py` — each cell records real Desktop grants of
  301 and 300 pages, the ordinary C client's map/Identify/window/write/damage
  order or pre-map refusal, retirement pixel scans, cleanup settlement, and
  QEMU screenshots tied to the recorded EFI/ESP, compiler, ELF, APB1, and
  emulator identities. These runs are distinct from the predicate-only
  `refusals-*` matrix.
- `lifecycle-cycles/`: `tools/v1_cycles.py` — ten launch/close cycles, each
  with its own cursor, instance-specific retirement and exit receipts,
  settlement against the pre-cycle baseline, and visual removal.
- `gate/`: the command transcript, stage receipts, and relevant host logs
  included before packaging; the `package`/`verify` receipts and final aggregate
  live in the sibling `*-packaging/` directory to avoid recursive self-reference.
- `env/`: environment recovery receipts (emulator identity, loader, TCG
  acceleration, toolchain versions, protected guards).

A missing serial log, a missing harness transcript, an absent identity or a
missing required artifact makes the run FAIL — see `docs/v1/V2-STATUS.md` §6.
