# Phase 13 evidence produced inside the formal regression suite

This is a complete, byte-for-byte copy of the Phase 13 run directory produced by `tools/test_phase13_registry_guest.py` while `tools/run_tests.sh` was executing for the full V1 gate. The raw evidence is preserved separately from the gate's host-level `regression.log` and receipt.

`run.json` records **PASS** against candidate `7a187b06099013d280c004116971ff1c926bfb7b`. The main workload completed in 391.726 seconds with the Phase 13 boot timeout **600 seconds, unchanged**; favorites reload completed in 9.028 seconds. Seed/AFS2 default timeouts remain 120 seconds. The directory retains exact EFI/ESP, serial output, append-only QMP and wait traces, boot receipts, virtual-console transcripts, and network/QEMU logs.

`SHA256SUMS` hashes every other file in this directory. This is supplementary evidence for the Phase 13 sub-run, not a standalone result for the entire 121-suite regression, not a 4b disposition, and not a V1 qualification verdict. The formal suite's overall status is recorded by the enclosing gate receipt and aggregate.
