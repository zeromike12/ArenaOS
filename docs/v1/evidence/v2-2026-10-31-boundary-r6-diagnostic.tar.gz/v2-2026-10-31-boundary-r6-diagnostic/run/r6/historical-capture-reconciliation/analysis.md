# Historical refusal-capture reconciliation

## Finding

The four historical refusal-matrix files were not newer QEMU screenshots. Each working-tree file was byte-for-byte equal to the corresponding committed PPM after decoding the committed bytes as UTF-8 with `errors="replace"` and encoding the resulting text back to UTF-8. This inserted `EF BF BD` replacement sequences and left 237,140–237,194 extra bytes beyond the declared 800x600 P6 raster. The resulting files were malformed as PPM captures. The copies in `current/`, the committed originals in `committed/`, `capture-identities.json`, and `historical-captures.diff` preserve both states before restoration.

For the three captures whose committed raster hash is `13f2b5c3a139af8b24933c5c8845039f7b56351e3b5d7ce49b57882867b53169`, the matching older `refusals-evidence.json` records that exact raster digest. The committed GCC `development-final` raster matches `401e007455eb2110a060a9e6f598b22e4ed0b0388a80cfdbd7905702deb44bd9`, also the digest recorded in its matching evidence JSON. This establishes the committed images as the evidence-consistent originals; the replacement-encoded working-tree files are not unique captures.

## Timeline and output-path check

- The last committed blobs are from `f3e1bde33204d2f652e9ced5a0203394f9b5e863` (`2026-10-30T17:12:21Z`). Their individual Git blob IDs and SHA-256s are recorded in `capture-identities.json`.
- The first surviving environment snapshot that records these paths as modified is r3 at `2026-10-30T22:48:29Z`; r4, r5, and r6 snapshots also show them modified. Current working-tree mtimes were `2026-10-31T21:18:18Z`.
- The archived historical development receipts identify `V1_EVIDENCE_DIR` under `development/` and `development-final/`, with `source_commit=be51fcb8c6a5e9547f61952d233f7e0fc13282d8` and run times `2026-10-30T17:00:40Z–17:01:32Z` and `17:04:42Z–17:05:32Z`. Those are the intended historical output roots.
- A search of current tracked code found no hard-coded use of those old evidence paths. The r6 command receipt names the unique r6 evidence root. There is no evidence that the r6 harness reused a historical output directory. The exact process that performed the later text transcoding is not present in the surviving logs, so its actor is recorded as unknown rather than attributed to a harness.

## Safe restoration

Only after preserving both versions and their binary diff, the four historical paths were restored from current `HEAD`. The replacement-encoded bytes remain preserved in this directory as diagnostic evidence; no distinct newer QEMU capture was discarded. New runs must use a unique evidence root and must never write into `development/` or `development-final/`.
