# Phase 13 QMP timeout evidence (r6)

## Original observation

The full-suite Phase 13 installed-application guest ran with the existing
`timeout_s=600` in `tools/test_phase13_registry_guest.py`. At timeout the
helper reported `serial=4804867 bytes; virtconsole=4713817 bytes` and ended
with:

- Process exit status 42 / surface 382.
- `AppInstance ProcessGroup teardown members=1; final members=0`.
- `filesd: lineage retired: 3 record(s) now stale` and one directory watch
  ended with the lineage.
- Application retirement for surface 382, mapping and region released.
- Resource detail transitioned from 24 AppInstances / 30 windows to 23 / 29;
  5 helpers and 5 stream sets remained.

This is evidence that at least one lifecycle teardown completed near timeout;
it does not identify the exact Python action currently waiting, nor prove
whether stale-record retirement was expected or causal. The same moment has
no host monotonic timestamp in the original logs.

## QMP client behavior and limits of the original diagnostic

The timeout helper called `timeout_diagnostics()` in `tools/mtest.py` before
killing QEMU. It made a new QMP connection with a 2-second connect deadline.
`tools/qmp.py` then used a 10-second socket timeout. The intended sequence was:

1. Read QMP greeting and issue `qmp_capabilities` in `Qmp.__init__`.
2. Issue `query-status`.
3. Issue `human-monitor-command: info registers` twice, with a short delay.
4. If an RIP was returned, request `x/16i <RIP>`.

The only retained result is the unqualified exception text
`QMP diagnosis unavailable: TimeoutError('timed out')`. The helper did not
record which handshake/command was in flight when the exception occurred.
No QMP status, register dump, RIP, or instruction sample was obtained. It is
therefore **unknown** from r6 whether QEMU's QMP event loop was blocked/starved
or the diagnostic client timed out at a different protocol step. This is not
classified as a guest CPU deadlock.

The raw `timeout-diagnostics.txt`, serial snapshots, virtconsole transcript,
QEMU stderr, setup-boot channels, and progress PPMs are stored beside this
file. The source snapshots in the diagnostic package preserve the exact r6
QMP and Phase 13 harness implementation.
