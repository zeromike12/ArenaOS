# v2-2026-10-31-boundary-r6-diagnostic — diagnostic evidence only

> **Qualification verdict: NOT QUALIFIED.** The observed full gate result is
> **FAIL**. This package is diagnostic
> evidence only; it makes no acceptance, qualification, merge, or release
> claim. Missing frames are listed as missing and are never synthesized.

## Run identity

- Source commit: `64efe9b858f8dce10b186ce7f80b8f47d041292d`
- Branch at run: `arena/af044828-arenaos`
- Code fingerprint: `c490b800801d067d3968801506b0a6f57946aad47fb5ece43fba0921a607e45d`
- EFI SHA-256: `b2fc4a295bfa5ef33c141f2fcfd099af5a761c25250592371996a02d6eba377a`
- ESP SHA-256: `a2f9821206c8efb22f13a6b3bcb92d5c6bd30b4bd60cef9bf3673b6280950551`
- Qualification status: NOT QUALIFIED; r6 classification remains failed.
- Raw PPM captures: included verbatim (not filtered like the qualification packager).
- Archive entries: 351; original file bytes: 247171197.

Runtime versions and hashes are summarized in `DIAGNOSTIC-REPORT.json`
(`runtime_identity`) and retained verbatim under `run/r6/env/`. Exact commands
are preserved in `DIAGNOSTIC-REPORT.json` (`command_transcripts`,
`full_gate_command_transcript`, and stage `argv` fields), with their original
`commands.txt` files under the run roots. Source snapshots are under
`source/64efe9b858f8dce10b186ce7f80b8f47d041292d/`.

## Stage verdicts

| Stage | Result | Finished UTC |
|---|---:|---|
| aggregate-controls | exit=0 | 2026-10-31T21:38:04Z |
| build | exit=0 | 2026-10-31T21:37:21Z |
| controls | exit=0 | 2026-10-31T21:38:03Z |
| cycles | exit=0 | 2026-10-31T21:45:19Z |
| env | exit=0 | 2026-10-31T21:37:57Z |
| guest-clang | exit=0 | 2026-10-31T21:42:03Z |
| guest-gcc | exit=1 | 2026-10-31T21:38:50Z |
| layout-integration-clang | exit=0 | 2026-10-31T21:44:17Z |
| layout-integration-gcc | exit=0 | 2026-10-31T21:41:10Z |
| package | exit=1 | 2026-11-01T00:22:54Z |
| phase15 | exit=0 | 2026-10-31T21:45:47Z |
| refusals-clang | exit=0 | 2026-10-31T21:42:28Z |
| refusals-gcc | exit=0 | 2026-10-31T21:39:20Z |
| regression | exit=1 | 2026-11-01T00:04:23Z |
| stability | exit=0 | 2026-11-01T00:22:54Z |
| verify | exit=2 | 2026-11-01T00:22:55Z |

The authoritative package and verification failures are retained at
`run/package-attempt/gate/logs/package.log` and
`run/package-attempt/gate/logs/verify.log`; the final aggregate is
`run/package-attempt/gate/logs/final-aggregate.log`.

## Requirement matrix

| Requirement | Verdict | Coverage |
|---|---|---|
| 1 | FAIL | Acknowledgment and visible response through production logic |
| 2 | FAIL | Successful checkpoint frames published and verified |
| 3 | PASS | Cleanup returns enforceable resources to baseline |
| 4 | PASS | Guest refusal matrix under both compilers |
| 4b | OPEN | Real stale/foreign capability case or M-recorded waiver |
| 5 | PASS | Final-artifact runtime stability (100/100 boots) |
| 5b | PASS | Canonical protected build and reproducible artifact identity |
| 5c | PASS | ESP embedded EFI identity |
| 5d | FAIL | Formal 121-suite regression on the candidate |
| 5e | PASS | C layout boundary predicates (exact-grant proof is separate) |
| 5f | PASS | Real-grant C integration: 301 accepted, 300 refused before map/write/window/damage |
| 5g | PASS | Phase-15 FP/SIMD/exception regression on the final EFI/ESP |
| 6 | PASS | Gate controls prevent partial or unsupported qualification claims |
| 7 | FAIL | Review evidence package sealed and fresh-extraction verified |

Requirement 4b remains OPEN: the recorded `foreign-identity` test mutates
identity bytes and is not a genuine foreign/stale capability launch. No M
waiver is present. Predicate-only proof (5e) and real-grant proof (5f) remain
distinct.

## Guest checkpoint verdicts and missing captures

The complete compiler-specific checkpoint records are in
`DIAGNOSTIC-REPORT.json` and the original `run/r6/guest-{gcc,clang}/evidence.json`.
The GCC pointer checkpoint remains a FAIL: `pointer input not proven: acknowledgment without a captured visible response (ack_ok=True visual_ok=False residual=False)`.

Missing required GCC captures:
- `guest-gcc/shots/cp05-mouse-response.png` (compiler `gcc`, checkpoint `5`)
- `guest-gcc/shots/cp06a-two-instances.png` (compiler `gcc`, checkpoint `None`)
- `guest-gcc/shots/cp06a-focused.png` (compiler `gcc`, checkpoint `None`)
- `guest-gcc/shots/cp06b-focused.png` (compiler `gcc`, checkpoint `None`)
- `guest-gcc/shots/cp07-desktop-restored.png` (compiler `gcc`, checkpoint `None`)
- `guest-gcc/shots/cp08-final-demonstration.png` (compiler `gcc`, checkpoint `None`)

The package also preserves `__ack-clear__.ppm`, the available final
`__ack-probe__.ppm`, and the pre-input mouse frame. Their presence is not
represented as a passing response frame.

## Phase 13 timeout

The installed-application guest exceeded its existing 600-second timeout.
The raw serial and virtconsole logs, QEMU stderr, setup boots, 30 progress PPM
captures, and original QMP timeout report are retained under
`run/r6/regression/phase13/`. The r6 helper recorded only
`TimeoutError('timed out')`; it did not record which QMP handshake/command was
blocked, and obtained no CPU/RIP sample. Therefore this package does not claim
to distinguish a QMP-client defect from a QEMU/event-loop stall.

## Layout real-grant evidence

The GCC and Clang integration JSON and QEMU captures are retained under
`run/r6/layout-integration-{gcc,clang}/`. The summary in
`DIAGNOSTIC-REPORT.json` records separate 301/300 results, page counts,
rendered band assertions, geometry-related fields, capture identities, and
resource drift. Screenshots supplement—not replace—the numeric and serial
proof.

## Historical PPM reconciliation

The four historical refusal-matrix files' current bytes, committed originals,
blob/SHA identities, and binary diff are preserved under
`run/r6/historical-capture-reconciliation/`. The working-tree bytes were an
exact UTF-8 replacement-character transformation of committed PPM bytes, not
new screenshots. The original historical paths were restored only after both
states were preserved. The exact process that caused the text transformation
is unknown; no surviving evidence attributes it to a newer harness.

## Omitted reproducible inputs

Read `run/r6/omitted-inputs.json`. It distinguishes reproducible runtimes/build
outputs from raw evidence. No raw log or capture was omitted to reduce size.
The current `build/scratch.img` hash is explicitly **not** the Phase 13 run
input: the original timed-out disk was overwritten by later gate work and its
run-time hash was not recorded.

## Independent archive verification

The archive manifest covers every file except the manifest itself. Verify from
a fresh extraction with:

```sh
python3 tools/v1_diagnostic_evidence.py verify v2-2026-10-31-boundary-r6-diagnostic.tar.gz
```

This verifies diagnostic archive integrity only. It does not run the strict
qualification checks and cannot change any stage or requirement verdict.
