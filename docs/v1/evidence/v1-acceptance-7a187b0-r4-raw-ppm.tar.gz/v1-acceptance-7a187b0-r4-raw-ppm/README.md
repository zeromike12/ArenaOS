# Supplemental raw PPM working copies — candidate 7a187b0, gate r4

This archive retains all 84 original PPM captures from the uncompressed r4 guest-gate evidence tree. The strict PNG-based qualification package `v1-acceptance-7a187b0-r4.tar.gz` was independently packaged and fresh-extraction verified; its manifest records the capture/raster identities. PPM is a fixed header plus the same raster as the PNG, so the strict package excludes these larger copies. This separate supplement restores the original PPM bytes without changing that strict archive or its verdict.

`raw/` preserves each capture's original relative path. `SHA256SUMS` records each PPM digest; `SHA256SUMS.raw` records the digest of that manifest. The outer archive has its own adjacent `.sha256` sidecar.

These files are archival raw captures, not a qualification verdict. The gate remains **BLOCKED / NOT ACCEPTED** because Requirement 4b is OPEN absent M's explicit disposition. Historical failures remain historical.
