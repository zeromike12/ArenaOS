# ArenaOS testing correction evidence — 2026-10-27

This archive is the retrievable raw-evidence companion to draft PR #6
(`arena/fd828627-arenaos`). It is not a milestone qualification package and
does not bless the runner's `qualify` mode.

## Tested source

- Tested full-run source: `30fe81047ff4a5c44a09d959bb92b7558c7891e9`
- Branch: `arena/fd828627-arenaos`
- Reviewed correction base: `fc943da`
- Correction commits tested here:
  - `71e94fd33da9a96ba3b74bab02d8e7243c073e58` — fail-closed cache,
    output-independent timeouts, sealed/portable run verification.
  - `ab38d4d1c59066c860495aef969fba414d7d96ba` — ignore the absent root
    manifest sentinel in the cache scan.
  - `30fe81047ff4a5c44a09d959bb92b7558c7891e9` — preserve feeder-error
    boots and archive-preflight raw evidence; wait for Phase 13's detailed
    resource receipt instead of racing its serial emission.
- Documentation/evidence publication commits after `30fe810` add this
  archive and its reports only. Inspect them with
  `git log --stat 30fe810..HEAD`; they are not part of the tested source
  identity above.

## Backend identity

- Host: 2 CPUs, about 3.8 GiB RAM, Python 3.11.2, Debian GCC 12.2.0.
- Rust: official 1.97.0, commit
  `2d8144b7880597b6e6d3dfd63a9a9efae3f533d3`.
- Official libcore SHA-256:
  - `x86_64-unknown-none`:
    `6b75c5188dca46c917a67ade52dddea81460f96dc4732003cebea2e22a5b1b09`
  - `x86_64-unknown-uefi`:
    `a7de36b0262b7d94cdcf1acb3f78288e7f5a57d546568b3ccaec27cd122c5494`
- Emulator: pinned patched QEMU 11.1.2, explicit TCG.
  - Wrapper SHA-256:
    `92ec1c12cc174d549dfdbedf921984784252d66630bdeca32d248085b42c76a1`
  - Emulator binary SHA-256:
    `e0ea2b1f5ae2a5aa65a455eb232e46e1743b5c327c48ca678630c214c69f26ff`
  - Unpatched control binary SHA-256:
    `443c81fc9482493297ae7a3f37300bef3a82a2873e428f72884cf52d16e27284`
    (its isolated-glibc wrapper is
    `284bdab88795a88be553a7419caafe1524a9a671497f4add58511ae1c74b3f56`).
- OVMF CODE SHA-256:
  `7e34e3b83224968bb0714c0ebc88f75c5c37b4cc892c902e511ccc7a7c107f94`
- OVMF VARS template SHA-256:
  `5d2ac383371b408398accee7ec27c8c09ea5b74a0de0ceea6513388b15be5d1e`
- Isolated glibc 2.40: libc
  `eef95f26903e6f9ac6b8cb92df9ba5306ff01b4058ddf7f9ad6aaa986bb7f35f`,
  loader
  `63704534fba7799d309e9e16992ea7d11e709906bd44b72060c007461b970458`.
- Canonical desktop EFI reproduced:
  `7dcee4426edc4b2a204592a5680c27c5ee91d51e3231705641df2ca0d7e2bfe6`.
  ESP hashes vary between local builds because FAT metadata timestamps
  vary; no identity claim is made for the local ESP beyond each build/boot
  record's own hash.

## Full-run attempts (all retained and reported)

| Attempt | Source | Outcome | Duration | Notes |
|---|---|---:|---:|---|
| `20261027T141830Z-full-ab38d4d-108026-dc6887` | `ab38d4d` | FAIL, 137/138 | 6997.4s | `phase13-registry-guest` read the detailed receipt before its serial line arrived. Verification also exposed missing boot-record handling for feeder failures and missing raw evidence routing for the two archive-preflight wrappers. |
| `20261027T162612Z-full-30fe810-259917-b23647` | `30fe810` | FAIL, 137/138 | 7117.0s | `m9-resources` observed live-process count 17 where the test asserted the transient snapshot 15; settled counts and shared/pages/maps accounting were exact. `verify-run` reported this failed run evidence-complete. Ten preserved focused repeats then passed with count 15. |
| `20261027T183025Z-full-30fe810-434497-768c5a` | `30fe810` | PASS, 138/138 | 6866.0s | One uninterrupted serial `full`; 507 recorded boots, 84 intentional kills, 5866.0 boot-seconds, 166 build records. This third attempt was warm-cache: all 166 were hits (153.1s total, 0.922s average). |

For the two failed full attempts, this archive contains their run-level
records and the complete failing attempt directories. Their remaining
passing attempt trees are retained in the originating workspace but are
not duplicated here; the corrected passing full below is included whole.

## Contents

- `runs/full-corrected-20261027T183025Z-full-30fe810-434497-768c5a/` —
  complete corrected `full` run: selection snapshot, source status,
  environment, all attempt outputs, build/boot records and raw evidence.
- `runs/full-failed-attempt1-.../`, `runs/full-failed-attempt2-.../` —
  run-level records plus the failing Phase 13 / M9-resources attempts.
- `runs/quick-corrected-.../` — corrected-source quick run (10/10),
  including the infrastructure self-test attempt.
- `runs/backend-xm-controls-.../` — patched/unpatched #XM controls.
- `runs/archive-preflights-.../` and `runs/phase13-focused-.../` —
  focused evidence for the two concrete fixes found by full attempt 1.
- `runs/m9-resources-repeat10-.../` — ten preserved repeats after full
  attempt 2; all passed and all reported live-process count 15.
- `logs/` — console logs for quick/backend/focused/full runs, verifier
  outputs, cache representative and entry metadata, and
  `run-statistics.json`.
- `environment/` — environment report, fingerprint report, and rebuild
  logs for Rust/isolated glibc.
- `timing/` — pre-correction baseline document and timing TSV snapshots.
- `MANIFEST.json` — SHA-256 and size for every archive file except the
  manifest itself.
- `verify_manifest.py` — dependency-free extracted-archive checker.

## Representative cache evidence

On tested source `30fe810`, an isolated empty cache directory produced:

- Phase 9 base fingerprint:
  `a155af30432307edf665c2c343e5729b5764730c796e322e4441a4add8a56304`
- First `mtest.build`: MISS/STORED, 20.111s outer elapsed.
- Second: HIT, 0.982s outer elapsed (0.91s restore message).
- With `CARGO_PROFILE_RELEASE_OPT_LEVEL=0`: fingerprint
  `4210a322225a5690a910d62af146b50bb16aa1074a45886031cfca59ef83470d`,
  lookup `None` — it cannot restore the base image.
- Canonical desktop fingerprint:
  `da9326b225d2af19467c6df358ad13217619a94d105e12f7c2d48bdfa69efa14`,
  computed in 0.636s over 1419 tree files and 28 Cargo configs.

Full attempt 2 at the same source had 48 miss-stored builds (552.0s,
11.499s average) and 118 hits (96.7s, 0.819s average). Full attempt 3 was
therefore warm-cache. Canonical direct builds on this host measured
36.447s cold and 1.784s warm, with the canonical EFI above.

## Verify after fresh extraction

From the directory containing the archive file or parts in the
repository:

```sh
mkdir -p /tmp/arena-evidence-check
cp arenaos-testing-correction-evidence-30fe810.tar.gz.sha256 \
  /tmp/arena-evidence-check/
# Single-file distribution:
cp arenaos-testing-correction-evidence-30fe810.tar.gz \
  /tmp/arena-evidence-check/
# Split distribution instead:
cat arenaos-testing-correction-evidence-30fe810.tar.gz.part-* \
  > /tmp/arena-evidence-check/arenaos-testing-correction-evidence-30fe810.tar.gz
cd /tmp/arena-evidence-check
sha256sum -c arenaos-testing-correction-evidence-30fe810.tar.gz.sha256
mkdir extracted
tar -xzf arenaos-testing-correction-evidence-30fe810.tar.gz -C extracted
python3 extracted/arenaos-testing-correction-evidence-30fe810/verify_manifest.py \
  extracted/arenaos-testing-correction-evidence-30fe810
```

Then, in a checkout of the tested source (`30fe810`), verify the complete
run directories from the extracted tree:

```sh
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/full-corrected-20261027T183025Z-full-30fe810-434497-768c5a
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/quick-corrected-20261027T202533Z-quick-30fe810-605011-2eb4dc
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/archive-preflights-20261027T161852Z-suite-30fe810-259357-b56a3d
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/phase13-focused-20261027T161936Z-suite-30fe810-259675-adfa05
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/m9-resources-repeat10-20261027T182829Z-suite-30fe810-434082-eb79ed
python3 tools/arena_test.py verify-run \
  /tmp/arena-evidence-check/extracted/arenaos-testing-correction-evidence-30fe810/runs/backend-xm-controls-20261027T141549Z-suite-ab38d4d-107020-614fc6
```

Do not run `verify-run` on the two `full-failed-attempt*` excerpts as if
they were whole runs: by design they contain the run-level records and
failing attempts only.

## Timing conditions

All timings are from this rebuilt 2-CPU/~3.8-GiB sandbox with pinned TCG.
They are component and run measurements under those conditions, not a
normalized claim against a different host or against the original
Phase 16 qualification attempt.
