ArenaOS VirtualBox interactive build
======================================

Requirement: x86-64 Oracle VirtualBox 7.2.22 with host hardware virtualization enabled.
Other VirtualBox versions are unverified. No guest additions or host tools are needed.

1. Extract this ZIP file.
2. Open ArenaOS-VDI.vbox in VirtualBox.
3. Select ArenaOS VDI 2c32009 and click Start.

ArenaOS boot diagnostics are captured automatically in ArenaOS-serial.log beside this file.
If the screen stays black or startup stops, power off the VM and send that file.

Use this new VDI settings file, not an older ArenaOS entry or .vbox file.
If the VM list still shows ArenaOS, open ArenaOS-VDI.vbox from this folder to add ArenaOS VDI 2c32009.

Register one extracted copy of this package. For later starts, select ArenaOS VDI 2c32009 in the VM list
instead of opening another extracted copy; VirtualBox registers disk UUIDs globally.

Interactive image source commit: 6a2635a898e074575f9b62935d2fe710cc0be442
Package generator source commit: 2c32009a87ecc0a611d395aa4680c33d1bbb6d31

The VM is configured with one CPU, 1024 MiB RAM, ICH9, EFI, VGA, PS/2 input,
an AHCI persistent data disk, one VirtIO network adapter using NAT, and
COM1 serial output captured in ArenaOS-serial.log beside this file.
The disks are VirtualBox native fixed VDI 1.1 images. The first SATA disk is
the 72 MiB writable data disk; the second contains the EFI
system partition. User files belong on the data disk and persist across boots.

This package is ready for external VirtualBox testing. Its exact guest has not
been started in the packaging environment. Display, input, storage persistence,
networking, shutdown, and repeated-boot behavior still require host validation.
Phase 15 remains PARTIAL / UNQUALIFIED; this interactive image is not qualification evidence.
