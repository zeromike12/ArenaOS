ArenaOS VirtualBox interactive build
======================================

Requirement: x86-64 Oracle VirtualBox 7.2.22 with host hardware virtualization enabled.
Other VirtualBox versions are unverified. No guest additions or host tools are needed.

1. Extract this ZIP file.
2. On Windows, double-click Start-ArenaOS.cmd. On Linux, run sh Start-ArenaOS.sh.
   The launcher registers this VM if needed, sets COM1 to an absolute log path in this folder, and starts the GUI.

If the screen stays black or startup stops, power off the VM and send ArenaOS-serial.log from this folder.

Use this package's launcher; do not start an older ArenaOS VM entry.
The launcher targets ArenaOS VDI ff4adb5; if you registered the VM by opening ArenaOS-VDI.vbox, it will use that same VM.

Register one extracted copy of this package; VirtualBox registers disk UUIDs globally.
Use the launcher for every start so the serial log path matches this extraction folder.

Interactive image source commit: 6a2635a898e074575f9b62935d2fe710cc0be442
Package generator source commit: ff4adb5c7d2743f57e546b4a393110206178c10b

The VM is configured with one CPU, 1024 MiB RAM, ICH9, EFI, VGA, PS/2 input,
an AHCI persistent data disk, one VirtIO network adapter using NAT, and
COM1 serial output saved to ArenaOS-serial.log beside this file by the launcher.
The disks are VirtualBox native fixed VDI 1.1 images. The first SATA disk is
the 72 MiB writable data disk; the second contains the EFI
system partition. User files belong on the data disk and persist across boots.

This package is ready for external VirtualBox testing. Its exact guest has not
been started in the packaging environment. Display, input, storage persistence,
networking, shutdown, and repeated-boot behavior still require host validation.
Phase 15 remains PARTIAL / UNQUALIFIED; this interactive image is not qualification evidence.
