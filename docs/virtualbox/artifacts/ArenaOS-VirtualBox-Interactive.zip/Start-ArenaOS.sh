#!/bin/sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
VBOXMANAGE=$(command -v VBoxManage || true)
if [ -z "$VBOXMANAGE" ]; then
    echo "VBoxManage was not found. Install Oracle VirtualBox and put VBoxManage on PATH." >&2
    exit 1
fi
VM_UUID='{c5dbd81b-4bbc-5dcf-b3a9-e36bc45aa9e4}'
if ! "$VBOXMANAGE" showvminfo "$VM_UUID" >/dev/null 2>&1; then
    "$VBOXMANAGE" registervm "$SCRIPT_DIR/ArenaOS-VDI.vbox"
fi
"$VBOXMANAGE" modifyvm "$VM_UUID" --uartmode1 file "$SCRIPT_DIR/ArenaOS-serial.log"
echo "Serial output will be saved to $SCRIPT_DIR/ArenaOS-serial.log."
exec "$VBOXMANAGE" startvm "$VM_UUID" --type gui
