@echo off
setlocal
set "VBOXMANAGE=%ProgramFiles%\Oracle\VirtualBox\VBoxManage.exe"
if not exist "%VBOXMANAGE%" (
  where VBoxManage >nul 2>&1
  if errorlevel 1 (
    echo VBoxManage.exe was not found. Install Oracle VirtualBox or add its folder to PATH.
    pause
    exit /b 1
  )
  set "VBOXMANAGE=VBoxManage"
)
set "VM_UUID=c5dbd81b-4bbc-5dcf-b3a9-e36bc45aa9e4"
"%VBOXMANAGE%" showvminfo "%VM_UUID%" >nul 2>&1
if errorlevel 1 (
  "%VBOXMANAGE%" registervm "%~dp0ArenaOS-VDI.vbox"
  if errorlevel 1 goto failed
)
"%VBOXMANAGE%" modifyvm "%VM_UUID%" --uartmode1 file "%~dp0ArenaOS-serial.log"
if errorlevel 1 goto failed
echo Serial output will be saved to "%~dp0ArenaOS-serial.log".
"%VBOXMANAGE%" startvm "%VM_UUID%" --type gui
if errorlevel 1 goto failed
exit /b 0

:failed
echo Could not configure or start the ArenaOS VM. Check that it is powered off and VirtualBox is installed.
pause
exit /b 1
