# ArenaOS Phase 16 corrected demonstration package

Package: `ArenaOS-Phase16-Demonstration-5aacbc8`

Classification: **CANONICAL CORRECTED QUALIFICATION CANDIDATE — NOT
ACCEPTED and not a release.** Phase 16 remains pending M/C acceptance.
Do not merge, publish a release, declare acceptance, or start Phase 17
from this package.

## Identity

- Final tested OS/test source:
  `5aacbc88c50d4565a7bb9f4075be27e40df27779`
- Branch: `arena/2b4ae1a5-arenaos`
- Final EFI:
  `7dcee4426edc4b2a204592a5680c27c5ee91d51e3231705641df2ca0d7e2bfe6`
- Final ESP:
  `04ffaf4681e92fe87886bdcff29b175df032ae9d88bd6cae59b34ad070ea674a`
- Protected Phase 14 PIE:
  `d7b0a8cf9c735c3898a867d824563f06b0d949df80fa1a9c96f9180a395fea2e`
- Protected signed Phase 14 APB1:
  `04add54f09042353fc42511978c82f8b8efb87f7d5f0657f9116f456276b3dfa`

The whole-archive SHA-256 is intentionally not embedded in this
archive. Compare the downloaded `.tar.gz` against the external
`.tar.gz.sha256` sidecar committed beside it under
`docs/phase16/artifacts/` in the repository.

## Contents

- `artifacts/` — corrected final EFI/ESP and protected Phase 14
  PIE/APB1.
- `firmware/` — the OVMF code/vars templates used for qualification.
- `evidence/canonical-corrected-5aacbc8-2026-10-26/` — corrected
  build, sensitivity, host, targeted guest, attempt, registered,
  strict Phase 15, and stability receipts.
- `screenshots/` — genuine corrected guest captures 07–09 with
  captions.
- `docs/` — ADR-0111/0112, compatibility notes, final report, issue
  register, Arena 1 handoff, provenance, backend recovery, and other
  Phase 16 submission docs. Included docs are the corrected
  pre-sealing texts; repository copies may add the whole-archive hash
  and post-sealing fresh-extraction result.
- `source/` — a focused 100-file tracked subset of tested commit
  `5aacbc8…`: the canonical C runtime, Rust dependency checksum/readme
  files, and the strict Phase 15 checker/harness imports needed by
  the package guest verifier. It is not the full repository tree.
- `MANIFEST.json`, `SHA256SUMS`, and `verify_package.py`.

The emulator itself is not bundled. Canonical guest evidence used the
identified locally modified QEMU 11.1.2 TCG binary
`e0ea2b1f5ae2a5aa65a455eb232e46e1743b5c327c48ca678630c214c69f26ff`
through wrapper
`92ec1c12cc174d549dfdbedf921984784252d66630bdeca32d248085b42c76a1`
under isolated glibc 2.40. Another emulator may be useful for an
exploratory boot, but it is not the canonical backend identity.

## Verify the downloaded archive

From the directory containing both downloaded files:

```sh
sha256sum -c ArenaOS-Phase16-Demonstration-5aacbc8.tar.gz.sha256
```

## Extract under a short prefix

QEMU Unix socket paths must remain below 108 bytes. Use a short
extraction prefix; the verifier fails closed before booting if the
generated socket paths would be too long.

```sh
mkdir -p /home/user/p16f
tar -xzf ArenaOS-Phase16-Demonstration-5aacbc8.tar.gz -C /home/user/p16f
cd /home/user/p16f/ArenaOS-Phase16-Demonstration-5aacbc8
```

## Static verification

Requirements: Python 3 and `pyfatfs` (used to prove the ESP contains
the exact packaged EFI).

```sh
python3 verify_package.py
```

Expected result: `STATIC PASS`, including all internal SHA-256
digests, manifest artifact identities, the 100-file source subset,
and an exact ESP inner-EFI comparison.

## Representative guest launch / verification

Guest mode runs the extracted `source/tools/test_m15_guest.py`
against the extracted EFI/ESP on both `max` AVX-capable and `qemu64`
CPU profiles. It uses the packaged firmware and creates its scratch
fixtures under `source/build/`. It explicitly requires a selected
emulator so an unknown system QEMU is not silently treated as the
canonical backend.

Canonical sandbox form:

```sh
ARENA_QEMU=/home/user/phase16-backend/qemu-patched \
ARENA_GLIBC_DIR=/home/user/glibc-2.40 \
python3 verify_package.py --guest
```

Equivalent explicit form:

```sh
python3 verify_package.py --guest --qemu /path/to/qemu-or-wrapper
```

Expected final lines include:

```text
Phase-15 native guest qualification: PASS (baseline and AVX-capable CPU profiles)
GUEST PASS: extracted EFI/ESP passed strict Phase 15 on both CPU profiles and remained unchanged
```

This checker is the supported representative launch path for the
package because a full ArenaOS boot also needs the harness's fresh
scratch-disk, network, console, keyboard, DNS/TCP, and QMP fixtures.
A bare QEMU command that reaches a shell is not a substitute for the
semantic guest receipts in `evidence/`.

## Rebuilding or rerunning the full suites

This package intentionally does not bundle downloaded toolchains,
the locally modified emulator, or the full 314 MB tracked tree with
historical checkpoint archives. To rebuild or rerun complete guest /
registered suites, use the repository branch at tested source commit
`5aacbc8…`, reconstruct the Rust/backend environment from
`docs/phase16/BACKEND-RECOVERY.md`,
`docs/phase16/dependencies/rust-1.97.0/README.md`, and the corrected
receipts' `environment.json`, and build at the physical
`/workspace/ArenaOS` bind-mount path required for protected Phase 14
byte identities.

Any change to EFI/ESP bits requires new final-artifact qualification;
do not reuse this package's stability receipt for a rebuilt image.

## Qualification summary

- Host: Rust 27/27; ABI 92 constants/no mismatches; C host 1721 PASS.
- Targeted GCC/Clang guests: Native/C1, C2, FP, live stdin, and
  Notification all exact PASS.
- Registered regressions: attempt 2 passed all 121 suites; the failed
  attempt 1 at the same source is retained in the evidence, not
  hidden.
- Strict Phase 15: PASS both CPU profiles on the corrected pair and
  preserved Phase 15 package.
- Stability: 100/100 boots fully green, fail=0, 942 s on the packaged
  EFI/ESP.

Post-sealing fresh-extraction receipts are intentionally outside this
archive in the repository under
`docs/phase16/receipts/canonical-corrected-5aacbc8-2026-10-26/fresh-archive/`.
