#!/usr/bin/env python3
"""Verify the ArenaOS Phase 16 corrected demonstration package.

Static mode verifies SHA256SUMS, MANIFEST.json identities, the focused
source manifest, and that the ESP contains the exact packaged EFI.

Guest mode additionally runs the extracted strict Phase 15 checker
against the extracted EFI/ESP on AVX-capable and qemu64 profiles. It
requires an explicitly selected QEMU command (--qemu or ARENA_QEMU) so
an unknown system emulator is never silently treated as the pinned
qualification backend.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_SOURCE = "5aacbc88c50d4565a7bb9f4075be27e40df27779"
IGNORED_PARTS = {"__pycache__"}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fail(message: str) -> int:
    print(f"FAIL: {message}", file=sys.stderr)
    return 1


def package_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == ROOT / "SHA256SUMS":
            continue
        rel = path.relative_to(ROOT)
        # The extracted strict checker creates source/build/. Those are
        # generated verification outputs, not sealed package contents.
        if rel.parts[:2] == ("source", "build") or any(p in IGNORED_PARTS for p in rel.parts):
            continue
        if path.suffix == ".pyc":
            continue
        files.append(path)
    return sorted(files)


def verify_static() -> int:
    manifest_path = ROOT / "MANIFEST.json"
    sums_path = ROOT / "SHA256SUMS"
    if not manifest_path.is_file() or not sums_path.is_file():
        return fail("MANIFEST.json or SHA256SUMS is missing")

    manifest = json.loads(manifest_path.read_text())
    if manifest.get("source_commit") != EXPECTED_SOURCE:
        return fail("manifest source_commit is not the corrected tested source")
    if manifest.get("package") != "ArenaOS-Phase16-Demonstration-5aacbc8":
        return fail("unexpected package name in manifest")

    listed: dict[str, str] = {}
    for line in sums_path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            expected, rel = line.split("  ", 1)
        except ValueError:
            return fail(f"malformed SHA256SUMS line: {line!r}")
        if rel in listed:
            return fail(f"duplicate SHA256SUMS entry: {rel}")
        listed[rel] = expected

    actual = {str(p.relative_to(ROOT)): p for p in package_files()}
    if set(listed) != set(actual):
        missing = sorted(set(listed) - set(actual))
        extra = sorted(set(actual) - set(listed))
        return fail(f"package file set differs from SHA256SUMS; missing={missing} extra={extra}")

    for rel, expected in sorted(listed.items()):
        got = digest(ROOT / rel)
        if got != expected:
            return fail(f"SHA-256 mismatch for {rel}: {got} != {expected}")

    for rel, identity in manifest.get("artifacts", {}).items():
        path = ROOT / rel
        if not path.is_file():
            return fail(f"manifest artifact missing: {rel}")
        if path.stat().st_size != identity.get("bytes") or digest(path) != identity.get("sha256"):
            return fail(f"manifest identity mismatch: {rel}")

    source_manifest = json.loads((ROOT / "source/SOURCE-MANIFEST.json").read_text())
    if source_manifest.get("source_commit") != EXPECTED_SOURCE:
        return fail("source manifest commit mismatch")
    files = source_manifest.get("files", {})
    if source_manifest.get("file_count") != len(files):
        return fail("source manifest file_count mismatch")
    for rel, identity in files.items():
        path = ROOT / "source" / rel
        if not path.is_file() or path.stat().st_size != identity.get("bytes") or digest(path) != identity.get("sha256"):
            return fail(f"source subset identity mismatch: {rel}")

    # The ESP must contain exactly the packaged EFI. test_m15_guest.py also
    # performs this check in guest mode; doing it statically catches a
    # mismatched pair before any boot.
    try:
        from pyfatfs.PyFatFS import PyFatFS
    except Exception as exc:  # fail closed, with the dependency named
        return fail(f"pyfatfs is required to verify the ESP inner EFI: {exc}")
    fs = PyFatFS(str(ROOT / "artifacts/arena-esp.img"), read_only=True)
    try:
        inner = fs.getbytes("/EFI/BOOT/BOOTX64.EFI")
    finally:
        fs.close()
    if inner != (ROOT / "artifacts/arena-boot.efi").read_bytes():
        return fail("ESP /EFI/BOOT/BOOTX64.EFI does not match artifacts/arena-boot.efi")

    print(
        f"STATIC PASS: {len(listed)} package files verified "
        f"(plus SHA256SUMS); source subset {len(files)} files; ESP inner EFI exact"
    )
    return 0


def socket_path_lengths() -> list[tuple[Path, int]]:
    build = ROOT / "source/build"
    names = (
        "vcon-phase15-avx.sock",
        "vcon-phase15-qemu64.sock",
        "qmp-phase15-avx.sock",
        "qmp-phase15-qemu64.sock",
    )
    return [(build / name, len(str(build / name).encode())) for name in names]


def verify_guest(qemu: str | None) -> int:
    rc = verify_static()
    if rc:
        return rc

    qemu_cmd = qemu or os.environ.get("ARENA_QEMU")
    if not qemu_cmd:
        return fail(
            "guest mode requires --qemu PATH or ARENA_QEMU so the emulator is explicit; "
            "for canonical reproduction use the pinned patched QEMU wrapper identified in MANIFEST.json"
        )

    lengths = socket_path_lengths()
    too_long = [(str(p), n) for p, n in lengths if n >= 108]
    if too_long:
        return fail(
            "extraction prefix is too long for QEMU Unix socket paths "
            f"(must be <108 bytes): {too_long}; re-extract under a short prefix such as /home/user/p16f"
        )
    print("Socket paths: " + ", ".join(f"{p.name}={n} bytes" for p, n in lengths))

    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    before = {
        rel: digest(ROOT / rel)
        for rel in ("artifacts/arena-boot.efi", "artifacts/arena-esp.img")
    }
    expected = {
        rel: manifest["artifacts"][rel]["sha256"] for rel in before
    }
    if before != expected:
        return fail("packaged EFI/ESP changed before guest verification")

    env = os.environ.copy()
    env["ARENA_QEMU"] = qemu_cmd
    env["ARENA_PHASE15_EFI"] = str(ROOT / "artifacts/arena-boot.efi")
    env["ARENA_PHASE15_ESP"] = str(ROOT / "artifacts/arena-esp.img")
    # Use the packaged firmware identities for this package verification,
    # regardless of any ambient sandbox firmware variables.
    env["ARENA_OVMF_CODE"] = str(ROOT / "firmware/OVMF_CODE_4M.fd")
    env["ARENA_OVMF_VARS"] = str(ROOT / "firmware/OVMF_VARS_4M.fd")

    checker = ROOT / "source/tools/test_m15_guest.py"
    print(f"Running extracted guest checker: {checker}")
    print(f"ARENA_QEMU={qemu_cmd}")
    proc = subprocess.run(
        [sys.executable, str(checker)],
        cwd=ROOT / "source",
        env=env,
        text=True,
    )
    if proc.returncode != 0:
        return fail(f"extracted strict Phase 15 guest checker exited {proc.returncode}")

    after = {rel: digest(ROOT / rel) for rel in before}
    if after != before:
        return fail(f"packaged EFI/ESP changed during guest verification: before={before} after={after}")

    print("GUEST PASS: extracted EFI/ESP passed strict Phase 15 on both CPU profiles and remained unchanged")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--guest", action="store_true", help="also boot the extracted artifacts with the strict Phase 15 checker")
    ap.add_argument("--qemu", default=None, help="explicit QEMU command/path for --guest (or set ARENA_QEMU)")
    args = ap.parse_args(argv)
    return verify_guest(args.qemu) if args.guest else verify_static()


if __name__ == "__main__":
    raise SystemExit(main())
