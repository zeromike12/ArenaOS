Third-party notices for the bundled GLib, Pixman, and Slirp shared libraries.
These files are Debian copyright metadata from the exact package sysroot used
for the pinned locally modified QEMU runtime. QEMU firmware/ROM licensing
notices are retained in ../pc-bios/.
