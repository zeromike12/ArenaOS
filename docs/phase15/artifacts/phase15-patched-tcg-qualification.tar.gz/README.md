# Phase 15 locally modified QEMU TCG qualification package

This is a runnable review package for the ArenaOS Phase 15 qualification candidate. It uses **locally modified QEMU 11.1.2 TCG** with explicit `-accel tcg`; it is not an upstream-QEMU or hardware-backed result. M retains final acceptance authority, and ADR-0113 remains Proposed.

## Package verification

Before extracting, verify the archive using the adjacent `.sha256` file in the ArenaOS repository. After extraction, install the pinned Python dependencies from official PyPI and run the independent manifest/evidence verifier:

```sh
python3 -m venv .venv-phase15
. .venv-phase15/bin/activate
python -m pip install -r overlay/tools/phase15_external/requirements.txt
python overlay/tools/verify_phase15_patched_tcg_archive.py .
```

The verifier checks every package file hash, strict two-profile receipts, all strict T2/T3/T4 per-boot receipts, control logs and image identities, the 121-suite regression marker, final source checks, and protected Phase 14 identities. See `manifest.json` for the complete file inventory and `evidence/` for raw receipts.

## Rebuild QEMU from the official source

The included `overlay/tools/build_phase15_patched_qemu.sh` downloads the official QEMU v11.1.2 source archive over HTTPS, checks SHA-256 `fc3d810fc6b27f60df77eaf6748004ca76de2edc2c4ff3a9f9a9ada33066c242`, applies the included patch for the `patched` variant, and builds the TCG-only x86-64 system emulator with the configure flags recorded in `overlay/docs/phase15/patched-tcg-qualification.json`. On Debian 13, install build prerequisites from the official Debian repositories with `build-essential curl tar patch meson ninja-build pkg-config python3 libglib2.0-dev libpixman-1-dev libslirp-dev`. The qualification build used GCC 14.2.0, Meson 1.6.1, Ninja 1.11.1, GLib 2.84.4, Pixman 0.44.0, and Slirp 4.8.0.

From the checked-out source root, run `tools/build_phase15_patched_qemu.sh patched /absolute/path/to/a/new-output-directory`. The directory must not already exist. The script verifies the official source archive before applying the patch. A rebuild with a different emulator SHA-256 is a different backend and does not inherit this qualification; use the distributed pinned binary for exact reproduction.

## Replay on x86-64 Linux

The overlay is for ArenaOS source commit `f54797f2fb5bac0b3440f986d2120382b3611ecc`. Clone the repository, check out that commit, and copy `overlay/.` into the checkout root. The host needs x86-64 Linux, glibc 2.38 or newer, Python 3.10+, the x86-64 dynamic loader, and the system `libpcre2-8`, zlib, `libatomic`, `libm`, and `libc`. The package supplies the pinned QEMU executable, GLib, Pixman and Slirp runtime objects, ROM data, exact EFI/ESP, OVMF, and control fixtures. Install Python packages only from the pinned official PyPI requirements.

Run `tools/build.sh --image` with the project’s pinned Rust toolchain to establish the production `desktop` profile and repeat the canonical source build. The runner still uses the package’s immutable strict EFI/ESP and matching firmware; it will reject any hash mismatch. Set the paths and run the strict preflight:

```sh
PKG=/absolute/path/to/extracted/package
QEMU_ROOT="$PKG/backend"
export ARENA_QEMU="env LD_LIBRARY_PATH=$QEMU_ROOT/runtime/lib $QEMU_ROOT/qemu-system-x86_64-patched -accel tcg -L $QEMU_ROOT/pc-bios"
export ARENA_OVMF_CODE="$PKG/firmware/OVMF_CODE_4M.fd"
export ARENA_OVMF_VARS="$PKG/firmware/OVMF_VARS_4M.fd"
export ARENA_PHASE15_EFI="$PKG/artifacts/arena-boot.efi"
export ARENA_PHASE15_ESP="$PKG/artifacts/arena-esp.img"
python tools/phase15_patched_tcg_qualification.py preflight   --qemu-binary "$QEMU_ROOT/qemu-system-x86_64-patched"   --lib-dir "$QEMU_ROOT/runtime/lib" --rom-dir "$QEMU_ROOT/pc-bios"   --efi "$ARENA_PHASE15_EFI" --esp "$ARENA_PHASE15_ESP"   --ovmf-code "$ARENA_OVMF_CODE" --ovmf-vars "$ARENA_OVMF_VARS"
```

For new trials, use `strict --receipts <empty-directory>` and `stability all --receipts <empty-directory>` with the same input flags shown above. Strict direct trials use both `max,+nx,+smep,+smap` and `qemu64,+nx,+smep,+smap`; official T2/T3/T4 stability uses the established `qemu64,+nx,+smep,+smap` profile. The stability harness does not retry failed boots and requires Phase 15 PASS, vector 19, status `0x113`, containment, and clean shutdown on every boot.

This package targets Linux TCG only. Windows/PowerShell and hardware accelerators were not executed. The existing KVM/WHPX external kit remains a separate hardware-only workflow and is not redefined by this package.

## Third-party notices

The packaged QEMU binaries are built from the hash-pinned official QEMU v11.1.2 source, and the package includes the corresponding patch and reproducible builder. The bundled GLib, Pixman, and Slirp runtime libraries retain their upstream license notices under `backend/licenses/`. QEMU's firmware/ROM notices are included in `backend/pc-bios/`. The pinned Python requirements are listed in the overlay.
