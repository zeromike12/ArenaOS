//! Minimal interrupt descriptor table — installed together with our GDT.
//!
//! WHY THIS EXISTS AT M1 (learned the hard way, see commit history):
//! EDK2 implements UEFI TPLs with the interrupt flag — every boot-service
//! call restores TPL_APPLICATION and executes `sti` on the way out. If we
//! swap the GDT without swapping the IDT, the next firmware timer interrupt
//! enters through a gate that selects the *firmware's* code segment (0x38),
//! which does not exist in our GDT → #GP in the firmware handler → #DF →
//! triple fault. The GDT and IDT must change hands together, atomically with
//! respect to interrupts (they are: we run IF=0 outside firmware calls, and
//! our own gates are in place before the first firmware call).
//!
//! Policy: vectors 0..31 get diagnostic stubs that log the vector, error
//! code, and interrupted context (plus CR2 for #PF) over serial, then halt
//! the machine (ADR-0005: crashes must produce useful diagnostics). Since
//! M2.1 a fault *armed as expected* by the test suite (`faults` module) is
//! instead recorded and recovered from — that is how the M2 suite proves
//! delivery, diagnosis, and resumption without dying. Vectors 32..255 share one absorb-and-EOI stub: external
//! interrupts arriving while we still borrow the firmware's devices are
//! acknowledged (8259 PIC EOI *and* LAPIC EOI — EDK2 runs this platform in
//! IOAPIC→LAPIC mode with the 8259s masked and unprogrammed; see the stub
//! comments) and ignored. The stub counts them so the M1 test suite can
//! *prove* real hardware interrupts flowed through our IDT.
//!
//! References: SDM Vol. 3 §6.10 (IDT, gate format), §6.12.1 (error codes),
//! §6.14.2 (LIDT/SIDT), §11 (APIC architecture; local-APIC EOI register),
//! Intel 8259A datasheet (EOI command).
//!
//! ABI notes: `x86-interrupt` is not stable Rust, so the stubs are written
//! with `global_asm!` and hand off to Rust via the target's win64/"C" ABI.
//! The interrupted RSP has *no* guaranteed alignment (the fault can hit any
//! instruction), so `exception_common` frames itself with RBP, saves all
//! caller-saved registers (the interrupted code may hold live values in
//! them — the handler is free to clobber them per ABI), and forces
//! RSP ≡ 0 mod 16 (`and rsp, -16`) before the `call`. The handler is an
//! ordinary `extern "C"` fn and may return (fault-recovery path), so the
//! stub unwinds exactly (`lea rsp, [rbp-72]`), restores the registers, and
//! `iretq`s whatever the (possibly rewritten) frame says.

use core::arch::global_asm;
use core::sync::atomic::{AtomicU64, Ordering};

use super::SyncCell;

/// Count of external interrupts absorbed by the ignore stub. The M1 test
/// suite enables IF briefly and requires this to advance — proof that real
/// device interrupts traverse our IDT, our stub, and an `iretq` intact.
static TIMER_IRQ_COUNT: AtomicU64 = AtomicU64::new(0);

pub fn absorbed_irq_count() -> u64 {
    TIMER_IRQ_COUNT.load(Ordering::Relaxed)
}

/// Address the absorb stub stores its LAPIC EOI to. Default: the
/// architectural default base (M1 runs before paging exists — same
/// documented assumption the stub always had). `paging::init` updates it
/// from the real IA32_APIC_BASE; the M2.7 kernel-entry sequence updates
/// it to the kernel-view alias. The stub reads it RIP-relative, so it
/// resolves to this same physical static under whichever alias executes.
static LAPIC_EOI_ADDR: AtomicU64 = AtomicU64::new(0xFEE0_00B0);

/// Address of the [`LAPIC_EOI_ADDR`] slot itself (M3.3b bring-up probe:
/// the same VA must read the same value under every process CR3 — the
/// kernel half is cloned by pointer, so any divergence is a paging bug).
pub fn lapic_eoi_slot_addr() -> u64 {
    core::ptr::addr_of!(LAPIC_EOI_ADDR) as u64
}

/// The EOI address the stub currently holds.
pub fn lapic_eoi_addr() -> u64 {
    LAPIC_EOI_ADDR.load(Ordering::Relaxed)
}

/// Point the absorb stub's LAPIC EOI at `addr` (must be mapped in the
/// currently live and the next address space at the time of the call).
pub fn set_lapic_eoi_addr(addr: u64) {
    LAPIC_EOI_ADDR.store(addr, Ordering::Relaxed);
}

/// Optional scheduler tick hook (M3.2, ADR-0013): called by the vector-32
/// handler *after* EOI and the absorb-counter bump, in interrupt context
/// (IF=0 via the interrupt gate, caller-saved registers saved by the stub).
/// Unset through boot and the whole M1/M2 lifecycle — with no hook the
/// timer stub's observable behavior is exactly the old absorb stub's.
/// `sched::preempt` installs it for the preemptive phase and removes it
/// after; the fn-pointer-in-atomic pattern matches `RESET_FN`/`LAPIC_EOI_ADDR`.
static TIMER_HOOK: AtomicU64 = AtomicU64::new(0);

/// Install (or remove, with `None`) the tick hook. Call with IF=0.
pub fn set_timer_hook(hook: Option<extern "C" fn()>) {
    TIMER_HOOK.store(hook.map_or(0, |f| f as usize as u64), Ordering::Relaxed);
}

/// Optional AUXILIARY tick hook (M6.4, ADR-0027): called by the same
/// vector-32 handler, before the scheduler's hook and independent of
/// whether preemption is armed.
///
/// It exists because the console's output mirror must not wake its
/// reader from where the bytes are produced: `serial::putc` runs in
/// every context there is, including inside the scheduler's own log
/// lines, and calling `ipc::notify` there would re-enter the
/// scheduler from underneath itself. The tap therefore only appends
/// and raises a flag, and the wake is delivered from here — an
/// ordinary interrupt context that is already allowed to wake threads.
/// `console::init` installs it (the same shape as the RX hook).
static TICK_AUX_HOOK: AtomicU64 = AtomicU64::new(0);

/// Install (or remove, with `None`) the auxiliary tick hook. IF=0.
pub fn set_tick_aux_hook(hook: Option<extern "C" fn()>) {
    TICK_AUX_HOOK.store(hook.map_or(0, |f| f as usize as u64), Ordering::Relaxed);
}

/// Rust half of `arena_irq_timer_stub` (vector 32 = the reclaimed PIT
/// tick, `drivers::intc::PIT_VECTOR`; the literal 32 below is kept local
/// because arch code does not import driver modules).
extern "C" fn arena_timer_handler() {
    // Dual-controller EOI, same discipline and rationale as the ignore
    // stub (M1 findings): 8259 cascade pair first (no-op when nothing is
    // in service — the 8259s are masked in this platform's IOAPIC mode),
    // then the LAPIC at whichever alias `paging`/kernel-entry installed.
    // EOI happens *before* the hook: the hook may context-switch, and the
    // controller must not be left with a vector in service across that.
    // SAFETY: fixed ports; LAPIC_EOI_ADDR always points at a mapped LAPIC
    // EOI register in the live view (set_lapic_eoi_addr contract).
    unsafe {
        super::outb(0xA0, 0x20);
        super::outb(0x20, 0x20);
        let eoi = LAPIC_EOI_ADDR.load(Ordering::Relaxed);
        (eoi as *mut u32).write_volatile(0);
    }
    TIMER_IRQ_COUNT.fetch_add(1, Ordering::Relaxed);
    let aux = TICK_AUX_HOOK.load(Ordering::Relaxed);
    if aux != 0 {
        // SAFETY: only set_tick_aux_hook writes this slot, always with
        // a real `extern "C" fn()` (or 0); the hook upholds the
        // interrupt-context contract (ADR-0013) exactly as the
        // scheduler hook below does.
        let f = unsafe { core::mem::transmute::<u64, extern "C" fn()>(aux) };
        f();
    }
    let hook = TIMER_HOOK.load(Ordering::Relaxed);
    if hook != 0 {
        // SAFETY: only set_timer_hook writes this slot, always with a
        // real `extern "C" fn()` (or 0); the hook itself upholds the
        // interrupt-context contract (ADR-0013).
        let f = unsafe { core::mem::transmute::<u64, extern "C" fn()>(hook) };
        f();
    }
}

/// Console RX hook (M4.6, ADR-0020): called by the vector-33 handler
/// *after* EOI, in interrupt context (IF=0 via the interrupt gate,
/// caller-saved registers saved by the stub). `console::init` installs
/// the UART drain; unset until then — with no hook the serial stub is
/// an absorb-and-EOI stub like the ignore stub. Same fn-pointer-in-
/// atomic pattern as `TIMER_HOOK`.
static SERIAL_HOOK: AtomicU64 = AtomicU64::new(0);

/// Install (or remove, with `None`) the console RX hook. Call with IF=0.
pub fn set_serial_hook(hook: Option<extern "C" fn()>) {
    SERIAL_HOOK.store(hook.map_or(0, |f| f as usize as u64), Ordering::Relaxed);
}

/// Rust half of `arena_irq_serial_stub` (vector 33 = COM1 RX,
/// `drivers::intc::SERIAL_RX_VECTOR`; the literal 33 lives at the
/// `SERIAL_RX_VECTOR` const below because arch code does not import
/// driver modules).
extern "C" fn arena_serial_handler() {
    // Dual-controller EOI BEFORE the hook, same discipline and rationale
    // as the timer handler: the hook may wake a thread, and the
    // controller must not be left with a vector in service across any
    // scheduler work.
    // SAFETY: fixed ports; LAPIC_EOI_ADDR contract as in the timer half.
    unsafe {
        super::outb(0xA0, 0x20);
        super::outb(0x20, 0x20);
        let eoi = LAPIC_EOI_ADDR.load(Ordering::Relaxed);
        (eoi as *mut u32).write_volatile(0);
    }
    let hook = SERIAL_HOOK.load(Ordering::Relaxed);
    if hook != 0 {
        // SAFETY: only set_serial_hook writes this slot, always with a
        // real `extern "C" fn()` (or 0); the hook upholds the
        // interrupt-context contract (ADR-0020: drain, feed, maybe
        // wake — never switch inside the ISR).
        let f = unsafe { core::mem::transmute::<u64, extern "C" fn()>(hook) };
        f();
    }
}

/// Rust half of the relay stubs (vectors 48..63, M5.1 / ADR-0021).
/// Dual-controller EOI FIRST — same discipline and rationale as the
/// timer/serial halves: the relay delivery may wake a thread, and the
/// controller must not be left with a vector in service across any
/// scheduler work. Then the vector goes to the relay table, which
/// notifies the registered (notification, badge) pair.
extern "C" fn arena_relay_handler(vector: u64) {
    // SAFETY: fixed ports; LAPIC_EOI_ADDR contract as in the timer half.
    unsafe {
        super::outb(0xA0, 0x20);
        super::outb(0x20, 0x20);
        let eoi = LAPIC_EOI_ADDR.load(Ordering::Relaxed);
        (eoi as *mut u32).write_volatile(0);
    }
    crate::relay::handle(vector);
}

global_asm!(
    // ---- exception stubs: 32 slots at a fixed 16-byte stride -------------
    // Each stub body is at most 9 bytes (push imm8 ×2 = 4, jmp rel32 = 5),
    // so `.p2align 4` guarantees stub N lives exactly at base + 16*N. The
    // Rust side (`exc_stub_addr`) relies on this stride — audited above.
    ".section .text",
    ".p2align 4",
    ".globl arena_exc_stubs",
    "arena_exc_stubs:",
    ".macro EXC_STUB vec, has_err",
    ".p2align 4",
    ".if \\has_err == 0",
    "push 0", // dummy error code: uniform stack shape for the common path
    ".endif",
    "push \\vec",
    "jmp exception_common",
    ".endm",
    "EXC_STUB 0, 0",  // #DE Divide Error
    "EXC_STUB 1, 0",  // #DB Debug
    "EXC_STUB 2, 0",  // NMI
    "EXC_STUB 3, 0",  // #BP Breakpoint
    "EXC_STUB 4, 0",  // #OF Overflow
    "EXC_STUB 5, 0",  // #BR Bound Range
    "EXC_STUB 6, 0",  // #UD Invalid Opcode
    "EXC_STUB 7, 0",  // #NM Device Not Available
    "EXC_STUB 8, 1",  // #DF Double Fault (error code always 0)
    "EXC_STUB 9, 0",  // (reserved; legacy #CS)
    "EXC_STUB 10, 1", // #TS Invalid TSS
    "EXC_STUB 11, 1", // #NP Segment Not Present
    "EXC_STUB 12, 1", // #SS Stack-Segment Fault
    "EXC_STUB 13, 1", // #GP General Protection
    "EXC_STUB 14, 1", // #PF Page Fault (CR2 holds the address)
    "EXC_STUB 15, 0", // (reserved)
    "EXC_STUB 16, 0", // #MF x87 FPU Error
    "EXC_STUB 17, 1", // #AC Alignment Check
    "EXC_STUB 18, 0", // #MC Machine Check
    "EXC_STUB 19, 0", // #XF SIMD Floating Point
    "EXC_STUB 20, 0", // #CP Control Protection
    "EXC_STUB 21, 1", // (reserved by SDM but documented with EC in some refs — keep shape)
    "EXC_STUB 22, 0", // (reserved)
    "EXC_STUB 23, 0", // (reserved)
    "EXC_STUB 24, 0", // (reserved)
    "EXC_STUB 25, 0", // (reserved)
    "EXC_STUB 26, 0", // (reserved)
    "EXC_STUB 27, 0", // (reserved)
    "EXC_STUB 28, 0", // #HV Hypervisor Injection
    "EXC_STUB 29, 0", // #VC VMM Communication
    "EXC_STUB 30, 1", // #SX Security Exception
    "EXC_STUB 31, 0", // (reserved)
    // ---- external interrupt stub (vectors 32..255) ------------------------
    // Absorb and acknowledge BOTH interrupt controllers, then bump the
    // absorbed-counter and iretq. No registers touched besides rax (saved).
    //
    // On this platform (QEMU q35 + EDK2/OVMF) the firmware routes the 8254
    // PIT through IOAPIC → LAPIC (vector 32) and leaves the legacy 8259 pair
    // fully masked (IMR=0xFF/0xFF) with its vector base UNPROGRAMMED
    // (irq_base=0). So:
    //   - LAPIC EOI (32-bit zero store to the EOI register, offset 0xB0, at
    //     the architectural default APIC base 0xFEE00000) clears the
    //     in-service bit for the firmware-delivered vector; without it the
    //     LAPIC blocks every later vector at that priority and at most ONE
    //     tick is ever absorbed. A no-op when nothing is in service.
    //   - 8259 cascade EOI (OCW2 0x20 to slave port 0xA0 then master 0x20)
    //     covers platforms/handoffs where the tick arrives through the legacy
    //     PIC; a no-op when the 8259 has nothing in service. Do NOT unmask
    //     8259 IRQ0 to "help": with irq_base=0 the ExtINT acknowledge via
    //     LINT0 delivers vector 0x00 — a #DE through our gate 0 (observed
    //     live; see docs/TESTING.md).
    // The post-M2 interrupt layer will read IA32_APIC_BASE and own both
    // controllers properly after ExitBootServices; M1 keeps the default base.
    ".p2align 4",
    ".globl arena_irq_ignore_stub",
    "arena_irq_ignore_stub:",
    "push rax",
    "mov al, 0x20",
    "out 0xa0, al",
    "out 0x20, al",
    "mov rax, [rip + {lapic_eoi}]",
    "mov dword ptr [rax], 0",
    "lock inc qword ptr [rip + {timer_count}]",
    "pop rax",
    "iretq",
    // ---- timer stub (vector 32, M3.2 / ADR-0013) ---------------------------
    // Same dual-controller EOI + absorb counter as the ignore stub (the
    // M1/M2 suites read that counter), plus a Rust handler that may call
    // the scheduler's tick hook. Frame discipline mirrors
    // exception_common: RBP frames the stub, all caller-saved registers
    // are saved (the interrupted thread may hold live values in any of
    // them, and the handler chain may context-switch — ADR-0013), RSP is
    // forced 16-aligned before the call. The tick hook (if installed)
    // runs with IF=0 (interrupt gate) and may switch threads; the
    // switched-away thread resumes by returning up this exact call chain
    // and iretq-ing into its interrupted body.
    ".p2align 4",
    ".globl arena_irq_timer_stub",
    "arena_irq_timer_stub:",
    "push rbp",
    "mov rbp, rsp",
    "push rax",
    "push rcx",
    "push rdx",
    "push rsi",
    "push rdi",
    "push r8",
    "push r9",
    "push r10",
    "push r11",
    "and rsp, -16",
    "sub rsp, 32",
    "call {timer_handler}",
    "lea rsp, [rbp - 72]",
    "pop r11",
    "pop r10",
    "pop r9",
    "pop r8",
    "pop rdi",
    "pop rsi",
    "pop rdx",
    "pop rcx",
    "pop rax",
    "pop rbp",
    "iretq",
    // ---- serial RX stub (vector 33, M4.6 / ADR-0020) ----------------------
    // Same frame discipline as the timer stub: the interrupted thread may
    // hold live values in any caller-saved register (the console IRQ can
    // land anywhere, ring 0 or ring 3), RBP frames the stub, RSP is
    // 16-aligned before the call. The Rust half EOIs both controllers
    // *first* (the handler feeds the console line discipline, which may
    // wake a blocked reader — enqueue-only, but the EOI-before-work rule
    // of ADR-0013 stays unbroken), then calls the installed hook.
    ".p2align 4",
    ".globl arena_irq_serial_stub",
    "arena_irq_serial_stub:",
    "push rbp",
    "mov rbp, rsp",
    "push rax",
    "push rcx",
    "push rdx",
    "push rsi",
    "push rdi",
    "push r8",
    "push r9",
    "push r10",
    "push r11",
    "and rsp, -16",
    "sub rsp, 32",
    "call {serial_handler}",
    "lea rsp, [rbp - 72]",
    "pop r11",
    "pop r10",
    "pop r9",
    "pop r8",
    "pop rdi",
    "pop rsi",
    "pop rdx",
    "pop rcx",
    "pop rax",
    "pop rbp",
    "iretq",
    // ---- IRQ relay stubs (vectors 48..63, M5.1 / ADR-0021) -----------------
    // 16 slots at a fixed 16-byte stride, same construction contract as the
    // exception stubs: each body is well under 16 bytes (push imm8 = 2,
    // jmp rel32 = 5 — gas may relax the jmp shorter, never longer), so
    // `.p2align 4` puts stub N exactly at base + 16*N and `relay_stub_addr`
    // can do the arithmetic.
    //
    // The vector travels on the STACK, not in a register, and that is the
    // whole point (M6.4 bug hunt — ADR-0027). The first version loaded it
    // with `mov rcx, \vec` before jumping to the common half, which saved
    // rcx only AFTERWARDS: the interrupted thread's rcx was already
    // destroyed, and `pop rcx` handed it back the VECTOR NUMBER. An
    // interrupt may land on any instruction, and rcx is a perfectly legal
    // place for live data (it is Win64's first argument register), so the
    // interrupted code resumed with 54 where its value had been. It cost a
    // day to find because it only bites when a relay fires while some
    // live value is in rcx — nothing did, until a console channel started
    // transmitting during process spawn. Push first, read later: exactly
    // what `exception_common` has always done with its vector.
    ".p2align 4",
    ".globl arena_relay_stubs",
    "arena_relay_stubs:",
    ".macro RELAY_STUB vec",
    ".p2align 4",
    "push \\vec",
    "jmp arena_relay_common",
    ".endm",
    "RELAY_STUB 48",
    "RELAY_STUB 49",
    "RELAY_STUB 50",
    "RELAY_STUB 51",
    "RELAY_STUB 52",
    "RELAY_STUB 53",
    "RELAY_STUB 54",
    "RELAY_STUB 55",
    "RELAY_STUB 56",
    "RELAY_STUB 57",
    "RELAY_STUB 58",
    "RELAY_STUB 59",
    "RELAY_STUB 60",
    "RELAY_STUB 61",
    "RELAY_STUB 62",
    "RELAY_STUB 63",
    // Stack on entry: [vector][RIP][CS][RFLAGS][RSP][SS] — the same shape
    // exception_common sees (minus the error code). Save EVERY register
    // the Rust handler may clobber BEFORE touching any of them, then read
    // the vector back off the stack as Win64 argument 1.
    ".p2align 4",
    "arena_relay_common:",
    "push rbp",
    "mov rbp, rsp",
    "push rax",
    "push rcx",
    "push rdx",
    "push rsi",
    "push rdi",
    "push r8",
    "push r9",
    "push r10",
    "push r11",
    "and rsp, -16",
    "sub rsp, 32",
    "mov rcx, [rbp + 8]",       // the vector the stub pushed, as arg 1
    "call {relay_handler}",
    "lea rsp, [rbp - 72]",
    "pop r11",
    "pop r10",
    "pop r9",
    "pop r8",
    "pop rdi",
    "pop rsi",
    "pop rdx",
    "pop rcx",
    "pop rax",
    "pop rbp",
    "add rsp, 8",               // drop the pushed vector
    "iretq",
    // ---- common exception path --------------------------------------------
    // Stack here: [vector][error_code][RIP][CS][RFLAGS][RSP][SS]
    // Hand (vector, error_code, &mut frame) to Rust in rcx/rdx/r8 (win64
    // ABI). The handler is an ordinary Rust fn, so it may clobber ALL
    // caller-saved registers — and the interrupted code may legitimately
    // hold live values in any of them (an exception can land on any
    // instruction). So the stub saves/restores rax,rcx,rdx,rsi,rdi,r8-r11
    // around the call; callee-saved registers are the handler's job per
    // ABI. RBP frames the stub: exact unwind via `lea rsp,[rbp-72]` (skips
    // the alignment slack), and the handler can rewrite frame.rip (fault
    // recovery) without losing our way back. Alignment audit in header.
    ".p2align 4",
    "exception_common:",
    "push rbp",
    "mov rbp, rsp",
    "push rax",
    "push rcx",
    "push rdx",
    "push rsi",
    "push rdi",
    "push r8",
    "push r9",
    "push r10",
    "push r11",
    "and rsp, -16",
    "sub rsp, 32",
    "mov rcx, [rbp + 8]",
    "mov rdx, [rbp + 16]",
    "lea r8, [rbp + 24]",
    "call {handler}",
    "lea rsp, [rbp - 72]",
    "pop r11",
    "pop r10",
    "pop r9",
    "pop r8",
    "pop rdi",
    "pop rsi",
    "pop rdx",
    "pop rcx",
    "pop rax",
    "pop rbp",
    "add rsp, 16",
    "iretq",
    timer_count = sym TIMER_IRQ_COUNT,
    lapic_eoi = sym LAPIC_EOI_ADDR,
    handler = sym arena_exception_handler,
    timer_handler = sym arena_timer_handler,
    serial_handler = sym arena_serial_handler,
    relay_handler = sym arena_relay_handler,
);

/// Hardware-pushed interrupt frame (SDM Vol. 3 §6.12.1, Figure 6-9): the
/// 64-bit form always pushes SS/RSP even for same-privilege faults.
#[repr(C)]
pub struct InterruptStackFrame {
    pub rip: u64,
    pub cs: u64,
    pub rflags: u64,
    pub rsp: u64,
    pub ss: u64,
}

/// Rust half of the common exception path (see asm above). Either recovers a
/// fault the test suite armed as expected (`faults` module: record what was
/// observed, resume the test at its recorded address) or — the production
/// path — prints full diagnostics and halts the machine (ADR-0005).
extern "C" fn arena_exception_handler(
    vector: u64,
    error_code: u64,
    frame: *mut InterruptStackFrame,
) {
    // #PF puts the faulting linear address in CR2; capture it before
    // anything (logging, recovery bookkeeping) can fault again and clobber.
    let cr2 = if vector == 14 { super::read_cr2() } else { 0 };

    // Controlled fault injection (M2.1): armed expectation matching this
    // vector → record the measured delivery and resume the test. Everything
    // else falls through to diagnostics + halt.
    if let Some(resume) = super::faults::take_expected(vector) {
        super::faults::record(vector, error_code, cr2);
        // SAFETY: `frame` points at the hardware-pushed values on the live
        // stub stack; rewriting RIP is exactly the documented recovery
        // contract, and `resume` came from the fault site itself.
        unsafe { (*frame).rip = resume };
        return;
    }

    // SAFETY: `frame` points at the hardware-pushed values directly above
    // the still-live stub stack; we are on the interrupted stack, single CPU,
    // and the values are plain reads. Stack faults (#DF/#SS-class) re-faulting
    // here are covered by the IST1 stacks installed in M2.1 for #DF/NMI/#MC.
    let (rip, cs, rflags, rsp, ss) = unsafe {
        let f = &*frame;
        (f.rip, f.cs, f.rflags, f.rsp, f.ss)
    };
    // ADR-0042: a real CPL3 exception is a PROCESS failure, not a
    // kernel failure. IDT entry does not swap GS; the last-thread exit
    // hook notifies the manager, which reaps through its Process cap.
    // Fatal CPU vectors and all CPL0 faults remain kernel-fatal.
    if cs & 3 == 3 && !matches!(vector, 2 | 8 | 18) {
        if let Some(pid) = crate::sched::current_proc_id() {
            crate::log::write_marker(format_args!(
                "[arena user fault] pid={pid} vector={vector:#04x} ({}) rip={rip:#x} cr2={cr2:#x}",
                vector_name(vector)
            ));
            super::syscall::exit_on_user_fault(vector);
        }
    }
    crate::log::write_marker(format_args!(
        "[arena PANIC fault] vector={vector:#04x} ({}) error_code={error_code:#x} rip={rip:#x} cs={cs:#x} rflags={rflags:#x} rsp={rsp:#x} ss={ss:#x} cr2={cr2:#x}",
        vector_name(vector),
    ));
    // Bring-up diagnostics (M3.3b): the stub's saved caller-saved
    // registers (exception_common pushes rax..r11 directly below the
    // hardware frame; frame = stub_rbp + 24) plus a bounded stack scan
    // for text-range return addresses — a frame-pointer-less backtrace.
    // SAFETY: production fault path halts; the stub stack is live and
    // readable, IF=0, reads are plain and bounded.
    unsafe {
        let sb = (frame as *const u8).sub(24) as *const u64; // stub RBP slot
        let srbp = *sb;
        let g = |i: usize| *((srbp as *const u64).sub(i));
        crate::log::write_marker(format_args!(
            "[arena PANIC regs] rax={:x} rcx={:x} rdx={:x} rsi={:x} rdi={:x} r8={:x} r9={:x} r10={:x} r11={:x}",
            g(1),
            g(2),
            g(3),
            g(4),
            g(5),
            g(6),
            g(7),
            g(8),
            g(9)
        ));
        if let Some(img) = crate::handoff::image_layout() {
            let kbase = img.base + super::paging::KERNEL_OFFSET;
            let tlo = kbase + 0x1000;
            let thi = tlo + 0x19000;
            let mut hits = 0usize;
            let mut sp = rsp & !7u64;
            for _ in 0..512 {
                let v = *(sp as *const u64);
                if v >= tlo && v < thi && hits < 10 {
                    crate::log::write_marker(format_args!(
                        "[arena PANIC bt] [sp={:x}] -> rva={:x}",
                        sp,
                        v - kbase
                    ));
                    hits += 1;
                }
                sp += 8;
            }
        }
    }
    crate::halt::halt_machine("cpu exception")
}

fn vector_name(v: u64) -> &'static str {
    match v {
        0 => "#DE Divide Error",
        1 => "#DB Debug",
        2 => "NMI",
        3 => "#BP Breakpoint",
        4 => "#OF Overflow",
        5 => "#BR Bound Range",
        6 => "#UD Invalid Opcode",
        7 => "#NM Device Not Available",
        8 => "#DF Double Fault",
        10 => "#TS Invalid TSS",
        11 => "#NP Segment Not Present",
        12 => "#SS Stack-Segment Fault",
        13 => "#GP General Protection",
        14 => "#PF Page Fault",
        16 => "#MF x87 FPU Error",
        17 => "#AC Alignment Check",
        18 => "#MC Machine Check",
        19 => "#XF SIMD Floating Point",
        20 => "#CP Control Protection",
        28 => "#HV Hypervisor Injection",
        29 => "#VC VMM Communication",
        30 => "#SX Security Exception",
        _ => "unknown/reserved",
    }
}

// ---------------------------------------------------------------------------
// IDT construction
// ---------------------------------------------------------------------------

/// 64-bit interrupt gate (SDM Vol. 3 §6.11, Table 3-2): P=1, DPL=0,
/// type=1110. Interrupt gates clear IF on entry — exactly our invariant
/// (handlers re-enable nothing; M2 decides policy per vector).
const GATE_INT64_PRESENT: u8 = 0x8E;

#[derive(Clone, Copy)]
#[repr(C, packed(2))]
struct IdtGate {
    /// bits 0..15 of the handler offset.
    offset_low: u16,
    /// Code-segment selector for the handler (must be a 64-bit CS).
    selector: u16,
    /// Byte 4 (SDM Vol. 3 Fig. 6-7): bits 0..2 = IST index (0 = no stack
    /// switch), bits 3..7 reserved/zero.
    ist: u8,
    /// Byte 5: bits 0..3 = gate type (0xE = 64-bit interrupt gate), bit 4 =
    /// S (must be 0), bits 5..6 = DPL, bit 7 = P.
    type_attr: u8,
    /// bits 16..31 of the handler offset.
    offset_mid: u16,
    /// bits 32..63 of the handler offset.
    offset_high: u32,
    /// Must be zero.
    reserved: u32,
}
const _: () = assert!(core::mem::size_of::<IdtGate>() == 16);

#[repr(C, packed(2))]
struct IdtDescriptor {
    limit: u16,
    base: u64,
}
const _: () = assert!(core::mem::size_of::<IdtDescriptor>() == 10);

const NUM_VECTORS: usize = 256;

static IDT: SyncCell<[IdtGate; NUM_VECTORS]> = SyncCell::new(
    [IdtGate {
        offset_low: 0,
        selector: 0,
        ist: 0,
        type_attr: 0,
        offset_mid: 0,
        offset_high: 0,
        reserved: 0,
    }; NUM_VECTORS],
);

static IDT_DESCRIPTOR: SyncCell<IdtDescriptor> = SyncCell::new(IdtDescriptor { limit: 0, base: 0 });

// Assembly stub symbols (defined in the global_asm! block above).
unsafe extern "C" {
    /// First of the 32 per-vector exception stubs, EXC_STUB_STRIDE apart.
    static arena_exc_stubs: u8;
    /// Shared absorb-and-EOI stub for vectors 34..255.
    static arena_irq_ignore_stub: u8;
    /// Full-frame timer stub for vector 32 (M3.2, ADR-0013).
    static arena_irq_timer_stub: u8;
    /// Full-frame serial RX stub for vector 33 (M4.6, ADR-0020).
    static arena_irq_serial_stub: u8;
    /// First of the 16 IRQ relay stubs (vectors 48..63), RELAY_STUB_STRIDE
    /// apart (M5.1, ADR-0021).
    static arena_relay_stubs: u8;
}

/// Vector carrying the PIT tick (`drivers::intc::PIT_VECTOR`; literal
/// here — arch does not import driver modules).
const PIT_TICK_VECTOR: usize = 32;

/// Vector carrying the COM1 RX interrupt (`drivers::intc::
/// SERIAL_RX_VECTOR`; literal here for the same reason).
const SERIAL_RX_VECTOR: usize = 33;

/// Stride between consecutive exception stubs (asm guarantees `.p2align 4`
/// and bodies ≤ 9 bytes, so each stub fits its 16-byte slot).
const EXC_STUB_STRIDE: usize = 16;

fn exc_stub_addr(vector: usize) -> u64 {
    debug_assert!(vector < 32);
    // Address arithmetic within the 32-stub block is in-bounds by the
    // stride audit at the asm site (`.p2align 4`, ≤9-byte bodies).
    core::ptr::addr_of!(arena_exc_stubs) as u64 + (vector * EXC_STUB_STRIDE) as u64
}

fn irq_stub_addr() -> u64 {
    core::ptr::addr_of!(arena_irq_ignore_stub) as u64
}

fn timer_stub_addr() -> u64 {
    core::ptr::addr_of!(arena_irq_timer_stub) as u64
}

fn serial_stub_addr() -> u64 {
    core::ptr::addr_of!(arena_irq_serial_stub) as u64
}

/// First vector of the IRQ relay range (M5.1, ADR-0021). The relay
/// stubs turn these vectors into notification deliveries (`crate::relay`).
pub const RELAY_VECTOR_BASE: usize = 48;

/// Size of the IRQ relay range: vectors 48..63 inclusive.
pub const RELAY_VECTOR_COUNT: usize = 16;

/// Stride between consecutive relay stubs (asm guarantees `.p2align 4`
/// and bodies ≤ 12 bytes, so each stub fits its 16-byte slot — the same
/// construction contract as the exception stubs, and `audit_gates`
/// checks every gate against it).
const RELAY_STUB_STRIDE: usize = 16;

/// Whether `vector` is one of the relay vectors (48..63).
pub const fn is_relay_vector(vector: usize) -> bool {
    vector >= RELAY_VECTOR_BASE && vector < RELAY_VECTOR_BASE + RELAY_VECTOR_COUNT
}

fn relay_stub_addr(vector: usize) -> u64 {
    debug_assert!(is_relay_vector(vector));
    // Address arithmetic within the 16-stub block is in-bounds by the
    // stride contract at the asm site (`.p2align 4`, ≤12-byte bodies).
    core::ptr::addr_of!(arena_relay_stubs) as u64
        + ((vector - RELAY_VECTOR_BASE) * RELAY_STUB_STRIDE) as u64
}

/// IST index per vector (SDM Vol. 3 §6.14.5): the exceptions that must
/// survive a corrupted/unmapped stack run on the dedicated IST1 stack from
/// `tss.rs`. 0 = no stack switch (normal behavior).
pub const fn ist_for(vector: usize) -> u8 {
    match vector {
        2 | 8 | 18 => 1, // NMI, #DF, #MC
        _ => 0,
    }
}

fn make_gate(handler: u64, ist: u8) -> IdtGate {
    IdtGate {
        offset_low: (handler & 0xFFFF) as u16,
        selector: super::gdt::KERNEL_CODE_SELECTOR,
        ist,
        type_attr: GATE_INT64_PRESENT,
        offset_mid: ((handler >> 16) & 0xFFFF) as u16,
        offset_high: (handler >> 32) as u32,
        reserved: 0,
    }
}

/// Build the 256-entry IDT and load it with LIDT.
///
/// # Safety
/// Ring 0, IF=0 (caller guarantees: installed right after the GDT swap in
/// `main`, which runs with interrupts masked), stubs reachable in the loaded
/// image.
pub unsafe fn init() {
    // SAFETY: single-writer boot-time init (SyncCell contract), caller
    // guarantees IF=0 so no interrupt can race table construction.
    unsafe {
        let idt = IDT.get();
        for vector in 0..NUM_VECTORS {
            let handler = if vector < 32 {
                exc_stub_addr(vector)
            } else if vector == PIT_TICK_VECTOR {
                timer_stub_addr()
            } else if vector == SERIAL_RX_VECTOR {
                serial_stub_addr() // M4.6: console RX (ADR-0020)
            } else if is_relay_vector(vector) {
                relay_stub_addr(vector) // M5.1: IRQ relays (ADR-0021)
            } else {
                irq_stub_addr()
            };
            // Write through the raw pointer; IdtGate is packed, so assign
            // the whole struct rather than borrowing fields.
            core::ptr::write(&mut (*idt)[vector], make_gate(handler, ist_for(vector)));
        }
        IDT_DESCRIPTOR.get().write(IdtDescriptor {
            limit: (core::mem::size_of::<[IdtGate; NUM_VECTORS]>() - 1) as u16,
            base: idt as u64,
        });
        core::arch::asm!("lidt [{}]", in(reg) IDT_DESCRIPTOR.get(),
            options(readonly, nostack, preserves_flags));
    }
}

/// M2.7 kernel-view switch: rewrite every gate's handler offset to its
/// `+offset` (kernel-view) alias and reload IDTR with this table's own
/// `+offset` alias. Runs while the boot-stage dual-view tables are still
/// live, so both aliases are valid at every instant.
///
/// # Safety
/// Ring 0, IF=0, `offset` = the kernel-view offset (KERNEL_OFFSET), and
/// the image window must be mapped at phys+offset in the view being
/// switched to (the kernel-view PML4 built by `paging::build_kernel_view`).
pub unsafe fn relocate_for_kernel(offset: u64) {
    // SAFETY: caller contract; single writer (boot sequence), IF=0.
    unsafe {
        let idt = IDT.get();
        for vector in 0..NUM_VECTORS {
            // Copy out (packed struct — never borrow fields), rewrite the
            // 64-bit offset, write the whole gate back.
            let gate = core::ptr::read(&(*idt)[vector]);
            let handler = u64::from(gate.offset_low)
                | (u64::from(gate.offset_mid) << 16)
                | (u64::from(gate.offset_high) << 32);
            core::ptr::write(&mut (*idt)[vector], make_gate(handler + offset, gate.ist));
        }
        IDT_DESCRIPTOR.get().write(IdtDescriptor {
            limit: (core::mem::size_of::<[IdtGate; NUM_VECTORS]>() - 1) as u16,
            base: (idt as u64) + offset,
        });
        core::arch::asm!("lidt [{}]", in(reg) IDT_DESCRIPTOR.get(),
            options(readonly, nostack, preserves_flags));
    }
}

/// M2.7 bring-up diagnostic: reconstruct the handler target of `vector`
/// twice — once through our `IDT` static, once through the table `sidt`
/// reports the CPU actually has loaded — and return both plus the `sidt`
/// base. Disagreement (or targets below `KERNEL_OFFSET` after relocation)
/// proves the CPU is walking a table other than the one we wrote.
///
/// # Safety
/// Ring 0 with the IDT mapped at both the static's address and the `sidt`
/// base (true under the dual view and the kernel view alike).
pub unsafe fn readback_gate(vector: usize) -> (u64, u64, u64) {
    fn target_of(g: IdtGate) -> u64 {
        u64::from(g.offset_low) | (u64::from(g.offset_mid) << 16) | (u64::from(g.offset_high) << 32)
    }
    // SAFETY: caller contract; both reads hit mapped table memory.
    unsafe {
        let via_static = target_of(core::ptr::read(&(*IDT.get())[vector]));
        let (base, _) = read_idtr();
        let via_idtr = target_of(core::ptr::read((base as *const IdtGate).add(vector)));
        (via_static, via_idtr, base)
    }
}

/// Audit the live IDT (located via `sidt`): count gates whose selector,
/// attribute/IST bytes, or handler offset deviate from the intended encoding
/// (KERNEL_CODE_SELECTOR, GATE_INT64_PRESENT, IST = `ist_for(vector)`,
/// offset = the stub `init` would install for that vector: exception stub
/// per vector < 32, the timer stub at `PIT_TICK_VECTOR`, the ignore stub
/// elsewhere). Returns (bad_selectors, bad_attrs, bad_offsets). Used by the
/// M1 suite as independent evidence that the table the CPU will walk is the
/// table we meant to build.
pub fn audit_gates() -> (usize, usize, usize) {
    let (base_addr, _) = read_idtr();
    let base = base_addr as *const u64;
    let mut bad_sel = 0usize;
    let mut bad_attr = 0usize;
    let mut bad_off = 0usize;
    for v in 0..NUM_VECTORS {
        // SAFETY: base is the live IDT (256 16-byte gates) per `sidt`;
        // read-only, IF-agnostic (table reads are not interruptible state).
        let lo = unsafe { base.add(v * 2).read_unaligned() };
        let hi = unsafe { base.add(v * 2 + 1).read_unaligned() };
        let sel = (lo >> 16) & 0xFFFF;
        let ist_byte = (lo >> 32) & 0xFF;
        let attrs = (lo >> 40) & 0xFF;
        let offset = (lo & 0xFFFF) | (((lo >> 48) & 0xFFFF) << 16) | (hi << 32);
        let want = if v < 32 {
            exc_stub_addr(v)
        } else if v == PIT_TICK_VECTOR {
            timer_stub_addr() // M3.2: the tick gets the hook-capable stub
        } else if v == SERIAL_RX_VECTOR {
            serial_stub_addr() // M4.6: console RX gets its own stub
        } else if is_relay_vector(v) {
            relay_stub_addr(v) // M5.1: IRQ relays get their own stubs
        } else {
            irq_stub_addr()
        };
        if sel != super::gdt::KERNEL_CODE_SELECTOR as u64 {
            bad_sel += 1;
        }
        if attrs != GATE_INT64_PRESENT as u64 || ist_byte != u64::from(ist_for(v)) {
            bad_attr += 1;
        }
        if offset != want {
            bad_off += 1;
        }
    }
    (bad_sel, bad_attr, bad_off)
}

/// Read back the IDTR (base, limit) with `sidt` — M1 test evidence that the
/// CPU accepted our table.
pub fn read_idtr() -> (u64, u16) {
    let mut desc = IdtDescriptor { limit: 0, base: 0 };
    // SAFETY: SIDT writes 10 bytes to a valid stack object; no side effects;
    // legal at ring 0.
    unsafe {
        core::arch::asm!("sidt [{}]", in(reg) &mut desc, options(nostack, preserves_flags));
    }
    (desc.base, desc.limit)
}

/// What `sidt` must report after [`init`].
pub fn expected_idt() -> (u64, u16) {
    (
        IDT.get() as u64,
        (core::mem::size_of::<[IdtGate; NUM_VECTORS]>() - 1) as u16,
    )
}
