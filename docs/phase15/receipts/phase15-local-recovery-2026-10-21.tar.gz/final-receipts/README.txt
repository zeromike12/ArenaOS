ArenaOS Phase 15 local recovery receipts
Date: 2026-10-21 UTC
Source commit: 989646771a0e288cefdaf0dabc5f5baa9bf1ed5c

The historical directory contains the complete uninterrupted 120-suite run,
all 2,000 raw per-test output/receipt files, and its exit status. Strict guest
directories contain the baseline and AVX-profile #XF attempts; the final run
uses QEMU 11.1.2 with explicit TCG and fails the vector-19 assertion. The
stability directories contain diagnostic-only T2/T3/T4 output and per-boot
pixel/lifecycle and DNS receipts. The diagnostic image explicitly skips #XF.
The Bochs files contain two independent-emulator startup trials; OVMF page
faulted before ArenaOS, so neither trial delivered an #XF result. The probes
directory contains the explicit QEMU/KVM initialization result.

No result in this archive qualifies hardware-backed #XF delivery. QEMU TCG
was the accelerator used for the guest suite and stability loops. The full
Phase 15 status remains PARTIAL / UNQUALIFIED.
