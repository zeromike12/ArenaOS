"""Independent strict TCG execution; no hardware qualification is claimed."""
from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
import time

r = Path(__file__).resolve().parent
ev = r / 'evidence'
runtime = r.parent / 'phase15-validation/runtime'
q = str(runtime / 'usr/bin/qemu-system-x86_64')
py = str(r / '.venv/bin/python')
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = str(runtime / 'usr/lib/x86_64-linux-gnu')
env['QEMU_MODULE_DIR'] = str(runtime / 'usr/lib/x86_64-linux-gnu/qemu')

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

manifest = json.loads((r / 'KIT-MANIFEST.json').read_text())

def verify_manifest():
    for name, rec in manifest['files'].items():
        p = r / name
        assert p.stat().st_size == rec['bytes'] and digest(p) == rec['sha256'], name

verify_manifest()
dependencies = {n: importlib.metadata.version(n) for n in ['pyfatfs', 'setuptools', 'fs', 'appdirs', 'six']}
(ev / 'python-dependencies.json').write_text(json.dumps(dependencies, indent=2) + '\n')

def run(label, cmd):
    start = time.monotonic()
    with (ev / (label + '.log')).open('w') as f:
        p = subprocess.run(cmd, cwd=r, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=280)
    rec = {'command': cmd, 'exit': p.returncode, 'elapsed_seconds': time.monotonic() - start}
    (ev / (label + '-exit.json')).write_text(json.dumps(rec, indent=2) + '\n')
    print(label, rec, flush=True)
    return p.returncode

run('official-kvm-runner', [py, '-u', 'tools/phase15_external/run_external.py', '--backend', 'kvm',
                         '--qemu', q, '--output-dir', str(ev / 'kvm-results')])
run('official-kvm-verifier', [py, 'tools/phase15_external/verify_receipt.py',
                           '--receipt', str(ev / 'kvm-results/receipt.json')])

wrapper = '''import sys,subprocess,os,json,time,datetime,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
runtime=Path(os.environ['P15_QEMU_RUNTIME'])
qemu=runtime/'usr/bin/qemu-system-x86_64'
args=sys.argv[1:]
cpu=args[args.index('-cpu')+1]
label='avx' if cpu.startswith('max') else 'qemu64'
cmd=[str(qemu),'-L',str(runtime/'usr/share/qemu'),'-accel','tcg',*args]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
p=subprocess.run(cmd)
record={'command':cmd,'backend':'tcg','cpu':cpu,'started_utc':started,'elapsed_seconds':time.monotonic()-start,'qemu_process_exit':p.returncode,'qemu_sha256':hashlib.sha256(qemu.read_bytes()).hexdigest()}
(r/'evidence'/('qemu-process-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\\n')
sys.exit(p.returncode)
'''
(r / 'record_qemu.py').write_text(wrapper)
env.update({'P15_QEMU_RUNTIME': str(runtime), 'ARENA_QEMU': py + ' ' + str(r / 'record_qemu.py'),
            'ARENA_PHASE15_SOCKET_MODE': 'tcp',
            'ARENA_PHASE15_EFI': str(r / 'artifacts/arena-boot.efi'),
            'ARENA_PHASE15_ESP': str(r / 'artifacts/arena-esp.img'),
            'ARENA_OVMF_CODE': str(r / 'artifacts/OVMF_CODE_4M.fd'),
            'ARENA_OVMF_VARS': str(r / 'artifacts/OVMF_VARS_4M.fd')})
runner_exit = run('strict-tcg-runner', [py, '-u', 'tools/test_m15_guest.py'])
verify_manifest()
logs = ev / 'tcg-guest-logs'
logs.mkdir()
for p in (r / 'build').iterdir():
    if p.is_file() and p.suffix in ('.log', '.txt'):
        shutil.copy2(p, logs / p.name)

sys.path.insert(0, str(r / 'tools/phase15_external'))
from run_external import classify_trial
profiles = []
for label in ['avx', 'qemu64']:
    serial_path = logs / f'serial-phase15-{label}.log'
    serial = serial_path.read_text(errors='replace')
    process = json.loads((ev / f'qemu-process-{label}.json').read_text())
    semantic = 97 if process['qemu_process_exit'] == 0 and 'RESULT FAIL' in serial else process['qemu_process_exit']
    stages = classify_trial(serial, process['qemu_process_exit'], semantic, False)
    profiles.append({'label': label, 'qemu_process_exit': process['qemu_process_exit'], 'semantic_exit': semantic,
                     'serial_sha256': digest(serial_path), 'stages': stages})
    print(label, stages, flush=True)

summary = {'schema': 'arenaos.phase15.work-independent-rerun.v1',
           'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'qualification_status': 'PARTIAL / UNQUALIFIED; no hardware-backed exception qualification',
           'backend_for_guest_trials': 'tcg', 'strict_runner_exit': runner_exit,
           'qemu_sha256': digest(q), 'kit_manifest_entries_verified_before_and_after': len(manifest['files']),
           'profiles': profiles, 'official_kvm_receipt': 'kvm-results/receipt.json',
           'source_changes': 'None to ArenaOS or kit sources. Standalone process recorder only.',
           'completed_gates': 'No official strict stability or release gates completed.'}
(ev / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
shutil.copy2(r / 'record_qemu.py', ev / 'record_qemu.py')
shutil.copy2(Path(__file__), ev / 'rerun.py')
shutil.copy2(r / 'KIT-MANIFEST.json', ev / 'KIT-MANIFEST.json')
print((ev / 'strict-tcg-runner.log').read_text()[-6500:], flush=True)
