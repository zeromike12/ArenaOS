import sys,subprocess,os,json,time,datetime,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
runtime=Path(os.environ['P15_QEMU_RUNTIME'])
qemu=runtime/'usr/bin/qemu-system-x86_64'
args=sys.argv[1:]
cpu=args[args.index('-cpu')+1]
label='avx' if cpu.startswith('max') else 'qemu64'
cmd=[str(qemu),'-L',str(runtime/'usr/share/qemu'),'-accel','tcg',*args]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
p=subprocess.run(cmd)
record={'command':cmd,'backend':'tcg','cpu':cpu,'started_utc':started,'elapsed_seconds':time.monotonic()-start,'qemu_process_exit':p.returncode,'qemu_sha256':hashlib.sha256(qemu.read_bytes()).hexdigest()}
(r/'evidence'/('qemu-process-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(p.returncode)
