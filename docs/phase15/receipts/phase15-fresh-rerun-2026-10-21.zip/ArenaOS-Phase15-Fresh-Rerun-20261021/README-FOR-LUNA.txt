ArenaOS Phase 15 — fresh independent rerun for Luna

This archive contains a NEW execution of the strict Phase 15 image, performed after the branch reached documentation commit 391c333d0a9a4ab0e8686e24848c92747e2a56ef. It does not reuse the prior run's serial or guest logs. Run timestamps are in environment.json and qemu-process-*.json.

RESULT: Phase 15 remains PARTIAL / UNQUALIFIED.

Both max,+nx,+smep,+smap and qemu64,+nx,+smep,+smap booted ArenaOS under stock QEMU 8.2.2 TCG. Both reported m15: RESULT FAIL (5/6). The unmasked negative SQRTSS probe changed MXCSR from 0x1F00 to 0x1F01 without vector 19. QEMU process exits were 0; semantic guest exits were 97; the unchanged strict test runner exited 1. The separate isolation, MMX, #MF/#UD containment, survivor and cleanup checks passed, and firmware shutdown was recorded. No #XF containment qualification is established.

Hardware-backed execution remains BLOCKED. /dev/kvm is absent, explicit KVM initialization exited 1, the official external runner returned 3 with a BLOCKED receipt, and its verifier returned 1 as expected.

Exact kit SHA256: 134cbc228e39508ab93909b87c6f839c59d9e89d3030aae15ce672b651bf4993
Kit obtained from commit e74d89dedb5fff8b942035b033f249a1400163c8; subsequent commit 391c333 changes documentation only. The compiled strict-image source remains the image source recorded by the official kit; this is not a new kernel build. All 28 manifested files and artifacts were verified before AND after this fresh run.

The QEMU runtime from the prior independent run was reused and its binary hash reverified: 8a35ccba41582fc6c38b9df85fc9e35fa1d42f414d2d7d8090ee9b2f5e7c0854. Package provenance is included. Pinned Python dependencies were installed in a fresh environment. The kit's existing TCP transport was used, with explicit -accel tcg. No kernel or kit source was changed. Standalone scripts only record execution and process exits.

Start with summary.json, then inspect tcg-guest-logs/serial-phase15-avx.log and serial-phase15-qemu64.log, strict-tcg-runner.log, qemu-process-*.json, and kvm-results/receipt.json. The official KVM receipt is BLOCKED; the separate TCG summary intentionally uses a different schema.

All evidence files are hashed in SHA256SUMS. In an extracted archive, run sha256sum -c SHA256SUMS from the evidence root. Verify the ZIP's externally supplied SHA256 before extraction.

No historical aggregate rerun, strict stability gate, release qualification, merge, or ADR acceptance is claimed by this rerun. Existing diagnostic evidence remains separately preserved in the repository.
