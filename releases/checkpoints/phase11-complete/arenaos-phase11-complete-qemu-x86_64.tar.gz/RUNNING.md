# ArenaOS phase11-complete

Verify the outer archive checksum and the extracted `sha256sums.txt`, then
install QEMU and Python 3 and run `python3 phase11_archive_boot.py` here.
No repository or build tree is needed. The script copies fresh OVMF
variables and the 72 MiB disk template; on that boot filesd formats the
AFS2 region and imports AFS1. It binds the included virtual-network test
peers, launches real graphical applications, injects keyboard and tablet
input, checks exact owned raster movement and process retirement, requires
the file service and the desktop surface online, then (same boot) creates a
folder from the desktop menu, opens it in a real Files process by
double-clicking its icon, creates a folder inside it with Ctrl+Shift+N, closes
Files with F8, and reads both folders back from the disk's AFS2 region on
the host. It then shuts down through the serial shell. Set ARENA_QEMU to a QEMU invocation if it is not on PATH.

The boot fixture still requires the virtual keyboard input `arena` before
the desktop starts (the historical inputd service mode); the script types it.
See FINAL-REPORT.md for what Phase 11 delivered and what it did not.
