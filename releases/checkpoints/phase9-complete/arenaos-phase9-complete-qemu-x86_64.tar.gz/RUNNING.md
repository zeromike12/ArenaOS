# Phase-9 qualified QEMU image

Verify the outer .tar.gz.sha256 and the extracted sha256sums.txt, install QEMU and Python 3, then run `python3 phase9_archive_boot.py` in this directory. The script copies fresh OVMF vars and a fresh AFS1 scratch platter, prebinds the included exact-query host UDP/TCP peers before QEMU, captures the actual display twice, injects a virtual keyboard key and checks the focused client pixel before orderly shutdown. The host DNS peer is required for the attached NIC and does not prove public/external DNS.
