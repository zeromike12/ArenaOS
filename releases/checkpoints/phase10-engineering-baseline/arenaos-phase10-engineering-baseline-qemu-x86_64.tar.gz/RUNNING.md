# ArenaOS Phase-10 Sol engineering baseline

Verify the outer archive checksum and extracted `sha256sums.txt`, then install
QEMU and Python 3 and run `python3 phase10_archive_boot.py` in this directory.
The standalone script requires no repository or build tree. It copies fresh
OVMF variables and the bundled AFS1 platter, binds the included virtual-network
test peers, launches real graphical applications, injects keyboard/tablet input,
checks exact owned raster movement and Process/resource retirement, relaunches,
then uses the independent serial shell for clean shutdown. Test peers do not
claim public DNS. Set ARENA_QEMU to a shell-tokenized portable QEMU invocation
if it is not on PATH; ARENA_EXTRACTED_EVIDENCE selects an evidence output folder.

For an interactive session use the QEMU device/firmware arguments in
phase10_archive_boot.py with a visible display and fresh writable disk copies.
The historical boot fixture requires virtual keyboard input `arena` before
desktop startup. The serial shell and graphical terminal are independent.
See MANUAL-SMOKE.md and DESIGN-HANDOFF.md for interaction and editing contracts.
