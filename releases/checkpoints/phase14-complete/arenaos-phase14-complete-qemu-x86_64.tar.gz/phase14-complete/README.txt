ArenaOS Phase-14 qualified native PIE and ASLR release

This archive contains the exact qualified EFI and ESP, the matching fresh
100/100 stability receipt, OVMF CODE and VARS template, a pristine AFS1/AFS2
scratch-disk template with three signed APB1 applications, the signed PIE ELF,
historical suite and Phase-14 guest/stability evidence, source documentation,
ADRs, and the independent extracted QEMU witness.

EFI SHA-256: 418c63acbf9eee0eadb6dd8de21e860bddd5e868d612028d7e93cb45e8d1ff2f

Requirements: Python 3, QEMU qemu-system-x86_64, and a POSIX host with Unix
sockets. Extract this archive and run:

    python3 phase14_archive_boot.py

The witness verifies every sha256sums.txt entry and the exact 100/100 EFI
receipt, then boots only these extracted files. It uses UEFI/OVMF, virtio
block, QEMU user networking, virtio RNG, virtio keyboard/tablet, and the
virtio-console test channel. It first installs and exercises the Phase-13
fixed-address ET_EXEC applications and runtime checks. It then installs the
signed Phase-14 APB1 using Desktop/filesd/packaged, checks the protected AFS2
executable and signature record, launches the PIE twice from All Applications,
checks relocated startup/data and two different kernel-selected bases, checks
exit 42 and exact process/Image teardown, and shuts down cleanly.

No checkout, build directory, runtime signing key, Rust toolchain, or hidden
fixture path is read. The APB1 signature comes from the repository's public
qualification test root and is a fixture signature, not a production key.
For a graphical Windows launch with a separate persistent disk, see
MANUAL-WINDOWS.md.
