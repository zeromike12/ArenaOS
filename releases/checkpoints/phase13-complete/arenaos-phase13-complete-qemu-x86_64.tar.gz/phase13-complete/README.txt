ArenaOS Phase-13 qualification archive

This package contains the exact qualified EFI and ESP, matching 100/100
stability receipt, OVMF CODE and VARS template, fresh AFS1/AFS2 scratch disk,
two signed APB1 fixtures, Phase-13 and Phase-12 closeout documents, ADRs,
qualification logs, tool versions, and the standalone guest witness.

Requirements: Python 3, QEMU qemu-system-x86_64, and a POSIX host with Unix
sockets. The witness uses only files beside this README plus the local QEMU
binary. From this extracted directory run:

    python3 phase13_archive_boot.py

The witness verifies sha256sums.txt and the EFI/100-boot receipt, boots these
files, installs both signed packages through Desktop, checks installed AFS2
payloads and records, explicitly opens a read-only document with the installed
handler, searches and launches through All Applications, observes three real
windows, helper and stream transfers, native VM/heap/threads/synchronization,
headless Process-cap exit, identity-resource teardown, and clean UEFI shutdown.
It also repeats the historical desktop, console, network, and process checks.
No checkout, build tree, Rust installation, or signing key is read.

The fixture signer is the public RFC 8032 test-vector key in apb1_format.py;
these packages are qualification fixtures, not production keys. The archive's
FINAL-REPORT.md copy omits its own outer archive digest to avoid an impossible
cryptographic self-reference; the repository final report records that exact
digest.
